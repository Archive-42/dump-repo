---
title: Clock
weight: 0
excerpt: feel free to try the examples
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<center>
<h2 style=" margin-bottom: 2em; align-self:center;">World Clock(Click To See Localized Time)</h2>
</center>

<iframe src="https://observablehq.com/embed/1b6399182c98cd36@480?cells=chart%2Cviewof+date" loading="lazy"
width="90%" height="629" frameborder="0">

<iframe src="https://codepen.io/bgoonz/full/QWgYoBp" loading="lazy"
width="90%" height="629" frameborder="0">
