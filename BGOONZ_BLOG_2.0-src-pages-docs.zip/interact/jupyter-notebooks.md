---
title: Jupyter Notebooks
weight: 0
excerpt: Jupyter Notebooks allow us to combine the power of a python script with the simplicity of a markdown file.
seo:
    title: 'Jupyter Notebooks'
    description: ' Jupyter Notebooks allow us to combine the power of a python script with the simplicity of a markdown file'
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

-   [Open Binder Jupyter Notebook](https://mybinder.org/v2/gh/bgoonz/Jupyter-Notebooks/439b0b3a1cae4bf7181996f1057221942c0c449f?filepath=00-Guide-to-Web-Scraping.ipynb)

<iframe src="https://mybinder.org/v2/gh/bgoonz/Jupyter-Notebooks/439b0b3a1cae4bf7181996f1057221942c0c449f" height="900px" width="100%">
</iframe>
