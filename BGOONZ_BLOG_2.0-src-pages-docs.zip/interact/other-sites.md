---
title: Other Websites
weight: 0
seo:
    title: Typography
    description: This is the typography page
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Typography
          keyName: property
        - name: 'og:description'
          value: This is the typography page
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Typography
        - name: 'twitter:description'
          value: This is the typography page
template: docs
---

<h1> Here are some other websites I have worked on since endeavoring to learn web development! </h1>

<br>
<h1>  Alternate Blog</h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  https://bgoonz-blog-v3-0.netlify.app/  " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<h1>  Games </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  https://bgoonz-games.netlify.app/  " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>

<h1>  Projects         </h1>
<br>

<iframe src=" https://project-portfolio42.netlify.app/  " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<h1>   Wordpress Site </h1>
<br>

<iframe class="inner" src="  https://web-dev-hub.com/  " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<h1>  Interview     </h1>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="   " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1>   Speach Recognition api </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="   " height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>

<h1>  The Algos Bgoonz Branch </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://bgoonz-branch-the-algos.vercel.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://thealgorithms.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
