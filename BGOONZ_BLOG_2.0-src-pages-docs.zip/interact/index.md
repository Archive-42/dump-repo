---
title: Interactive
weight: 0
excerpt: feel free to try the examples
seo:
  title: Interactive Examples
  description: here is content the user can interact with
  robots: []
  extra: []
  type: stackbit_page_meta
template: docs
---
*   [Data Structures Interactive](https://ds-algo-official.netlify.app/)

<iframe src="https://ds-algo-official.netlify.app/" height="900px" width="100%">
</iframe>

*   [Games](https://bgoonz-games.netlify.app/)

<iframe src="https://bgoonz-games.netlify.app/" height="900px" width="100%">
</iframe>



*   [Embeds](https://webdevhub42.notion.site/Embeds-a3b7edb038b246a0adbfed9de9c2a9ac)



<iframe src="https://random-static-html-deploys.netlify.app/embeds_notion" height="900px" width="100%">
</iframe>





