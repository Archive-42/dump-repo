---
title: Projects
excerpt: >-
    We'd love it if you participate in the Web-Dev-Hubcommunity. Find out how to
    get connected.
seo:
    title: Projects
    description: |+
        introductory-react-part-2
        a-very-quick-guide-to-calculating-big-o-computational-complexity
        introduction-to-react css-animations
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Projects Articles
          keyName: property
        - name: 'og:description'
          value: |+
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Projectss
        - name: 'twitter:description'
          value: This is the community page
        - name: 'og:image'
          value: images/beige-maple.png
          keyName: property
          relativeUrl: true
template: docs
weight: 0
---

<br>
<h1>  Links: </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://links4242.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>


<br>
<h1>  Search Awesome Lists      </h1>
<br>

<iframe src="https://bgoonz.github.io/searchAwesome/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<h1>  Useful Resource Archive #3   </h1>
<br>

<iframe src="https://useful-resource-repo3-0.vercel.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<hr>
<br>
<br>
<br>
<h1> Anywhere Fitness </h1>
<br>

<iframe src="https://frontend-iota.vercel.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<hr>
<br>

<hr>
<br>
<br>
<hr>
<br>
<br>
<h1>  Project Image Portfolio   </h1>
<br>

<iframe src="https://project-portfolio42.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<hr>
<br>

<hr>
<br>
<h1>  Web Audio DAW      </h1>
<br>

<iframe src="https://mihirbeg28.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>

<h1>React & Shopify Ecommerce Site (Norwex)     </h1>
<br>

<iframe src="https://friendly-amaranth-51833.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<br>
<h1>Bgoonz Bookmarks   </h1>
<br>

<iframe src="https://bgoonzbookmarks.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>

<h1>Portfolio </h1>
<br>

<iframe src="https://bg-portfolio.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<h1>Goal Tracker  </h1>
<br>

<iframe src="https://splendid-onion-b0ec3.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<h1>  Potluck Planner </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://potluck-landing.netlify.app/" height="800px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true" 
       frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<h1>Meditation App </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://meditate42app.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
