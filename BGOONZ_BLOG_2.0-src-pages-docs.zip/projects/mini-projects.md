---
title: Mini Projects
excerpt: >-
    We'd love it if you participate in the Web-Dev-Hubcommunity. Find out how to
    get connected.
seo:
    title: Mini Projects
    description: |+
        introductory-react-part-2
        a-very-quick-guide-to-calculating-big-o-computational-complexity
        introduction-to-react css-animations
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Mini Projects Articles
          keyName: property
        - name: 'og:description'
          value: |+
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Mini Projectss
        - name: 'twitter:description'
          value: This is the community page
        - name: 'og:image'
          value: images/beige-maple.png
          keyName: property
          relativeUrl: true
template: docs
weight: 0
---




<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/NWjrEWV?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWpRXzb?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/BaWEVqg?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/WNpqNYG?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWpMWzE?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/rNyENQJ?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/zYZVYMj?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/YzZozOM?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/gOmVErj?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/vYmYzqw?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/dyvBYNj?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ExWBVWb?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/XWMELYy?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWpmXxq?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/eYvMKwe?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWpmmom?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWpmmPm?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/JjWLLqj?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWpVVLP?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/gOmeeEm?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/NWgdZyq?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/RwKYRoo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/LYyBwEp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWgYoBp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ExZvGoZ?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWbxYme?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/dyOaoXb?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ExZxMPN?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ZEKOmYW?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/bGWgLaR?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWvMQrb?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/JjNXROo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/abWNmqo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/bGWpwvv?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/mdmPrwR?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/BaRKLZw?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/RwVaGZo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/BaRdabZ?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/OJWzbRa?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/KKaJwgo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ExZrayM?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/yLgZLrp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/dyNayLB?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/PoWVovN?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/VwPgwgo?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/YzNBzbK?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/NWdoWVp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/mdRvdzd?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/LYxqYMa?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/wvgNvYW?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/LYxqYBq?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/jOydOvm?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/ZELwEMv?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/oNBmNPV?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/WNRPbeO?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/poRGvzp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/WNRPNpw?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/NWdoWvN?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/LYxqEZP?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/wvgNByP?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/eYgxmyx?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/JjExopj?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/GRrzRGR?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/vYxGLao?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/abwzxKP?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/XWgJQYP?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/powvBZp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/wveBJBM?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWgwpGv?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/powvegw?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/eYRmvJV?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/GREgWEp?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/NWgdVOJ?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/QWgdVaa?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWmGPvO?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/rNmJMaz?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/MWmQjYJ?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe
  height="300"
  style="width: 100%"
  scrolling="no"
  title="Neural Network Visualization (animated SVG)"
  src="https://codepen.io/bgoonz/embed/eYWVdmR?default-tab=html%2Cresult"
  frameborder="no"
  loading="lazy"
  allowtransparency="true"
  allowfullscreen="true"
></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  title="searchblog2.0"
src="https://codepen.io/bgoonz/embed/LYyBwEp?default-tab=result&theme-id=dark" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/LYyBwEp">
searchblog2.0</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  title="Fibonacci Carousel" src="" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://replit.com/@bgoonz/Comments-1#index.html">
Fibonacci Carousel</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<br>
<iframe scrolling="yes" src="https://goonlinetools.com/covid19/global" style="border: 0px none;height: 540px; margin-top: -110px; margin-bottom: -220px; width: 100%;"> </iframe>
 <br>
 <br>
<hr>
 <br>
 <br>

<br>
<hr>
<br>

<hr>
<br>
<br>

<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  title="Fibonacci Carousel"
src="https://codepen.io/bgoonz/embed/JjNagJo?default-tab=result&theme-id=dark" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/JjNagJo">
Fibonacci Carousel</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  title="embed-twitter-feed"
src="https://codepen.io/bgoonz/embed/poPOqEO?default-tab=result&theme-id=dark" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/poPOqEO">
embed-twitter-feed</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  src="//jsfiddle.net/bgoonz/j4xt839d/embedded/result/"
allowfullscreen="allowfullscreen" frameborder="0"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  src="//jsfiddle.net/bgoonz/76osauer/1/embedded/result/"
allowfullscreen="allowfullscreen" frameborder="0"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  src="//jsfiddle.net/bgoonz/vtz7820m/embedded/result/dark/"
allowfullscreen="allowfullscreen" frameborder="0"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
src="//jsfiddle.net/bgoonz/1dye9uws/2/embedded/js,html,css,result/dark/" allowfullscreen="allowfullscreen"
frameborder="0"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe height="300" style="width: 90%;" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0"  src="//jsfiddle.net/bgoonz/3mpgzkx7/1/embedded/"
allowfullscreen="allowfullscreen" frameborder="0"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br> 
<br>
<br>
<br>
<iframe loading="lazy" src="https://codepen.io/bgoonz/embed/zYwJQaw?default-tab=html%2Cresult"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="hvbrd-sockets (forked)"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<br>
<iframe loading="lazy" src="https://codesandbox.io/embed/bigo-3wqy4?fontsize=14&hidenavigation=1&theme=dark"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="hvbrd-sockets (forked)"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<iframe loading="lazy"
src="https://codesandbox.io/embed/hvbrd-sockets-forked-vsi2o?fontsize=14&hidenavigation=1&theme=dark"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="hvbrd-sockets (forked)"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<br>
<br>
<iframe loading="lazy" src="https://codesandbox.io/embed/summer-surf-p6dei?fontsize=14&hidenavigation=1&theme=dark"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="summer-surf-p6dei"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<br> <br>
<br>
<iframe loading="lazy"
src="https://codesandbox.io/embed/sharp-feistel-x8bvv?fontsize=14&hidenavigation=1&theme=dark"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="sharp-feistel-x8bvv"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

<br>
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no"
title="3D Cover Flow in React! | @keyframers 3.7"
src="https://codepen.io/bgoonz/embed/ExZvGoZ?default-tab=html%2Cresult" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz42/pen/RwpeaWr'>3D Cover Flow in React! | @keyframers
3.7</a> by Bryan
C Guner
(<a href='https://codepen.io/bgoonz42'>@bgoonz42</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Simple Typing Carousel "
src="https://codepen.io/bgoonz/embed/ExZvGoZ?default-tab=html%2Cresult" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/ExZvGoZ">
Simple Typing Carousel </a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no"
title="3D Cover Flow in React! | @keyframers 3.7"
src="https://codepen.io/bgoonz42/embed/RwpeaWr?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz42/pen/RwpeaWr'>3D Cover Flow in React! | @keyframers
3.7</a> by Bryan
C Guner
(<a href='https://codepen.io/bgoonz42'>@bgoonz42</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Video Background 1"
src="https://codesandbox.io/embed/bgoonzblog20-oo3x5?fontsize=14&hidenavigation=1&theme=dark"
style="width:90%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="bgoonzblog2.0"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Video Background 1"
src="https://codepen.io/bgoonz/embed/BaRLKBd?default-tab=html%2Cresult&theme-id=dark" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/BaRLKBd">
Video Background 1</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<br>

<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no"
title="CSS-only Colorful Calendar Concept" src="https://documentation-site-react2.vercel.app/"
frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/vYmKQYj">
  CSS-only Colorful Calendar Concept</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="FullTextSearchjs"
src="https://codepen.io/bgoonz/embed/QWvMWoQ?default-tab=html%2Cresult" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/QWvMWoQ">
  FullTextSearchjs</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="CSS Grid: Info Card"
src="https://codepen.io/bgoonz42/embed/MWmpjmy?default-tab=html%2Cresult" frameborder="no" loading="lazy"
allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz42/pen/MWmpjmy">
  CSS Grid: Info Card</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz42">@bgoonz42</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no"
title="CSS-only Colorful Calendar Concept"
src="https://codepen.io/bgoonz/embed/vYmKQYj?default-tab=html%2Cresult&theme-id=dark" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/vYmKQYj">
  CSS-only Colorful Calendar Concept</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Dashed Border Generator"
src="https://random-static-html-deploys.netlify.app/dashed-border-generator.html" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/bgoonz/pen/wvdgypd">
  Dashed Border Generator</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Particle tornado"
src="https://codepen.io/bgoonz/embed/VwPwRvr?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/VwPwRvr'>Particle tornado</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="A Simple Fade Effect on Scroll"
src="https://codepen.io/bgoonz/embed/OJWzbRa?height=375&theme-id=dark&default-tab=html,result"
frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/OJWzbRa'>A Simple Fade Effect on Scroll</a> by Bryan C
Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Controlled Text Example"
src="https://codepen.io/bgoonz/embed/oNZYbjZ?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/oNZYbjZ'>Controlled Text Example</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="MatrixCode"
src="https://codepen.io/bgoonz/embed/KKaKbQX?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/KKaKbQX'>MatrixCode</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="TroisJS InstancedMesh Test"
src="https://codepen.io/bgoonz/embed/oNBNJMK?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/oNBNJMK'>TroisJS InstancedMesh Test</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="What's behind ?"
src="https://codepen.io/bgoonz/embed/mdRdaQV?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/mdRdaQV'>What's behind ?</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------Vector Swarm------------------------------------------->
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="VectorSwarm"
src="https://codepen.io/bgoonz/embed/BapavbW?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/BapavbW'>VectorSwarm</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Canvas Sparkly Circle Loader"
src="https://codepen.io/bgoonz/embed/ExZxMPN?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/ExZxMPN'>Canvas Sparkly Circle Loader</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Canvas particles"
src="https://codepen.io/bgoonz/embed/bGgGZEZ?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/bGgGZEZ'>Canvas particles</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Inline Styles with React"
src="https://codepen.io/bgoonz/embed/WNRjBoO?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/WNRjBoO'>Inline Styles with React</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Constellation"
src="https://codepen.io/bgoonz/embed/zYNYbqK?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/zYNYbqK'>Constellation</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="95 000 particles"
src="https://codepen.io/bgoonz/embed/PoWoLNy?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/PoWoLNy'>95 000 particles</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<p class="codepen" data-height="575" data-theme-id="dark" data-default-tab="html,result" data-user="bgoonz"
data-slug-hash="DmnlJ"
style="height: 375px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;"
data-pen-title="Simple Responsive Form">
<span>See the Pen <a href="https://codepen.io/chriscoyier/pen/DmnlJ">
    Simple Responsive Form</a> by Bryan Guner (<a href="https://codepen.io/chriscoyier">@bgoonz</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Smooth Page Scrolling in jQuery"
src="https://codepen.io/bgoonz/embed/KKamLNy?height=375&theme=dark&default-tab=html,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/KKamLNy'>Smooth Page Scrolling in jQuery</a> by Bryan C
Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Demo Flexbox 3"
src="https://codepen.io/bgoonz/embed/ZELKNBo?height=375&theme=dark&default-tab=css,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/ZELKNBo'>Demo Flexbox 3</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Scroll Drawing"
src="https://codepen.io/bgoonz/embed/abpWrBP?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/abpWrBP'>Scroll Drawing</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Light Javascript Table Filter"
src="https://codepen.io/bgoonz/embed/qBRmGqw?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/qBRmGqw'>Light Javascript Table Filter</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
<br>
<br>
<iframe loading="lazy"
src="https://codesandbox.io/embed/cold-firefly-si5u1?fontsize=14&hidenavigation=1&theme=dark"
style="width:95%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="cold-firefly-si5u1"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy"
src="https://codesandbox.io/embed/determined-star-57xlk?fontsize=14&hidenavigation=1&theme=dark"
style="width:95%; height:575px; border:0; border-radius: 4px; overflow:hidden;" title="determined-star-57xlk"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"></iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="CSS Grid: Excel Spreadsheet"
src="https://codepen.io/bgoonz/embed/abJYgGX?height=375&theme=dark&default-tab=css,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/abJYgGX'>CSS Grid: Excel Spreadsheet</a> by Bryan C
Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="3D Drag out menu with guitar"
src="https://codepen.io/bgoonz/embed/QWpmXxq?height=375&theme=dark&default-tab=css,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/QWpmXxq'>3D Drag out menu with guitar</a> by Bryan C
Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no"
title="Navigation bar with circle flexible highlight POC"
src="https://codepen.io/bgoonz/embed/eYvMwKL?height=375&theme=dark&default-tab=css,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/eYvMwKL'>Navigation bar with circle flexible highlight
  POC</a> by
Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="gsuiOscilloscope"
src="https://codepen.io/bgoonz/embed/eYvrgpe?height=375&theme=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/eYvrgpe'>gsuiOscilloscope</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="510" style="width: 90%;" scrolling="no" title="random quote(React.js)"
src="https://codepen.io/bgoonz/embed/ZEeoyKv?height=510&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/ZEeoyKv'>random quote(React.js)</a> by Bryan C Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<!-------------------------------------------------------------------------------------->
<br>
<br>
<br>
<iframe loading="lazy" height="575" style="width: 90%;" scrolling="no" title="Web Audio API: Lightning Talk"
src="https://codepen.io/bgoonz/embed/GRWdvNm?height=375&theme-id=dark&default-tab=js,result" frameborder="no"
loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href='https://codepen.io/bgoonz/pen/GRWdvNm'>Web Audio API: Lightning Talk</a> by Bryan C
Guner
(<a href='https://codepen.io/bgoonz'>@bgoonz</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>
 <br>
 <br>
<hr>
 <br>
 <br>
<br>
<br>
