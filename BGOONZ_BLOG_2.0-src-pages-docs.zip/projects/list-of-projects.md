---
title: List Of Projects
excerpt: >-
    We'd love it if you participate in the Web-Dev-Hubcommunity. Find out how to
    get connected.
seo:
    title: List Of Projects
    description: |+
        introductory-react-part-2
        a-very-quick-guide-to-calculating-big-o-computational-complexity
        introduction-to-react css-animations
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: List Of Projects Articles
          keyName: property
        - name: 'og:description'
          value: |+
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: List Of Projectss
        - name: 'twitter:description'
          value: This is the community page
        - name: 'og:image'
          value: images/beige-maple.png
          keyName: property
          relativeUrl: true
template: docs
weight: 0
---


1.  [ WEB DEV RESOURCE HUB ](https://web-dev-resource-hub.netlify.app)

2.  [Learn Redux](https://learning-redux42.netlify.app/)

3.  [ Data Structures Website ](https://trusting-dijkstra-4d3b17.netlify.app)

4.  [Web-Dev-Quizzes](https://web-dev-interview-prep-quiz-website.netlify.app/intro-js2.html)

5.  [ Recursion ](https://zen-lamport-5aab2c.netlify.app)

6.  [React Documentation Site](https://csb-ov0d1-bgoonz.vercel.app/)

7.  [ Blogs-from-webdevhub ](https://amazing-hodgkin-33aea6.netlify.app)

8.  [ Realty Website Demo ](https://angry-fermat-dcf5dd.netlify.app)

9.  [ Best-Prac & Tools ](https://boring-heisenberg-f425d8.netlify.app)

10. [site-analysis](https://site-analysis.netlify.app/)

11. [ a/AOpen Notes ](https://clever-bartik-b5ba19.netlify.app)

12. [ Iframe Embed Playground ](https://code-playground.netlify.app)

13. [ Triggered Effects Guitar Platform ](https://condescending-lewin-c96727.netlify.app)

14. [ Live Form ](https://determined-dijkstra-666766.netlify.app)

15. [ Interview Questions ](https://determined-dijkstra-ee7390.netlify.app)

16. [ Resources Compilation ](https://eager-northcutt-456076.netlify.app)

17. [ React Blog Depreciated ](https://ecstatic-jang-593fd1.netlify.app)

18. [ MihirBeg.com ](https://eloquent-sammet-ba1810.netlify.app)

19. [ Embeded Html Projects ](https://embedable-content.netlify.app)

20. [ Cheat Sheets ](https://festive-borg-e4d856.netlify.app)

21. [ Early Version Of WebDevHub ](https://focused-pasteur-0faac8.netlify.app)

22. [ My Gists ](https://gists42.netlify.app)

23. [ DS-Algo-Links ](https://gracious-raman-474030.netlify.app)

24. [ Video Chat App ](https://happy-mestorf-0f8e75.netlify.app)

25. [ Ciriculumn ](https://hungry-shaw-30d504.netlify.app)

26. [ Cheat Sheets ](https://inspiring-jennings-d14689.netlify.app)

27. [ Links ](https://links4242.netlify.app)

28. [ Medium Articles ](https://modest-booth-4e17df.netlify.app)

29. [ NextJS Blog Template ](https://modest-torvalds-34afbc.netlify.app)

30. [ React Demo ](https://modest-varahamihira-772b59.netlify.app)

31. [ Ecomerce Norwex V1 ](https://nervous-swartz-0ab2cc.netlify.app)

32. [ Gifs ](https://objective-borg-a327cd.netlify.app)

33. [ Excel2HTML ](https://pedantic-wing-adbf82.netlify.app)

34. [ Data Structures Site ](https://pensive-meitner-1ea8c4.netlify.app)

35. [ Portfolio ](https://portfolio42.netlify.app)

36. [ Page Templates ](https://priceless-shaw-86ccb2.netlify.app)

37. [ Photo Gallary ](https://quizzical-mcnulty-fa09f2.netlify.app)

38. [ Coffee Website ](https://relaxed-bhaskara-dc85ec.netlify.app)

39. [ Awesome Resources ](https://romantic-hamilton-514b79.netlify.app)

40. [ Cheat Sheets ](https://silly-lichterman-b22b5f.netlify.app)

41. [ Link City ](https://silly-shirley-ec955e.netlify.app)

42. [ VSCODE Extensions ](https://stoic-mccarthy-2c335f.netlify.app)

43. [ webdevhub manual attempt ](https://web-dev-resource-hub-manual-deploy.netlify.app)

44. [ Norwex Resources ](https://wonderful-pasteur-392fbe.netlify.app)

45. [idk ](https://zen-bhabha-bd046f.netlify.app)

46. [heroku bare bones template](https://getting-started42.herokuapp.com/)

47. [bad reads](https://bad-reads42.herokuapp.com/)

48. [docusaurus](https://documentation-site-react2.vercel.app/)

49. [stackbit](https://app.stackbit.com/studio/609b2d7c71a5dd0016f36326)




---


# More:


- [https://determined-dijkstra-ee7390](https://determined-dijkstra-ee7390)
- [https://bgoonz-blog](https://bgoonz-blog.netlify.app)

---

- [https://github.com/stackbit-projects/best-celery-b2d7c](https://github.com/stackbit-projects/best-celery-b2d7c)
- [https://sanity-gatsby-blog-3-web-dnkdb4p7](https://sanity-gatsby-blog-3-web-dnkdb4p7.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog3](https://github.com/bgoonz/sanity-gatsby-blog3)
- [https://ds-algo-official](https://ds-algo-official.netlify.app)

---

- [https://github.com/bgoonz/DS-ALGO-OFFICIAL](https://github.com/bgoonz/DS-ALGO-OFFICIAL)
- [https://bgoonz-blog-v3-0](https://bgoonz-blog-v3-0.netlify.app)

---

- [https://github.com/bgoonz/alternate-blog-theme](https://github.com/bgoonz/alternate-blog-theme)
- [https://sanity-signup](https://sanity-signup.netlify.app)

---

- [https://github.com/bgoonz/successful-cabbage](https://github.com/bgoonz/successful-cabbage)
- [https://bgoonz-bookmarks](https://bgoonz-bookmarks.netlify.app)

---

- [https://github.com/side-projects-42/superb-celery](https://github.com/side-projects-42/superb-celery)
- [https://side-bar-blog-4](https://side-bar-blog-4.netlify.app)

---

- [https://github.com/bgoonz/cool-hickory](https://github.com/bgoonz/cool-hickory)
- [https://bicknborty](https://bicknborty.netlify.app)

---

- [https://github.com/bgoonz/searching-bick-n-borty-api](https://github.com/bgoonz/searching-bick-n-borty-api)
- [https://blog3-backup-dd7df](https://blog3-backup-dd7df.netlify.app)

---

- [https://github.com/bgoonz/blog3-backup](https://github.com/bgoonz/blog3-backup)
- [https://bgoonzmedium](https://bgoonzmedium.netlify.app)

---

- [https://github.com/bgoonz/My-Medium-Blog](https://github.com/bgoonz/My-Medium-Blog)
- [https://adoring-nobel-85c068](https://adoring-nobel-85c068.netlify.app)

---

- [https://github.com/bgoonz/ntn-boilerplate](https://github.com/bgoonz/ntn-boilerplate)
- [https://random-static-html-deploys](https://random-static-html-deploys.netlify.app)

---

- [https://github.com/bgoonz/random-static-html-page-deploy](https://github.com/bgoonz/random-static-html-page-deploy)
- [https://docs42](https://docs42.netlify.app)

---

- [https://github.com/bgoonz/docs-collection](https://github.com/bgoonz/docs-collection)
- [https://bgoonzblog20starter](https://bgoonzblog20starter.netlify.app)

---

- [https://github.com/bgoonz/graceful-pine](https://github.com/bgoonz/graceful-pine)
- [https://marvelous-aluminum-11a84](https://marvelous-aluminum-11a84.netlify.app)

---

- [https://github.com/bgoonz/marvelous-aluminum](https://github.com/bgoonz/marvelous-aluminum)
- [https://memes42069](https://memes42069.netlify.app)

---

- [https://github.com/stackbit-projects/oceanic-pluto-4029d](https://github.com/stackbit-projects/oceanic-pluto-4029d)
- [https://dev-journal42](https://dev-journal42.netlify.app)

---

- [https://github.com/bgoonz/smart-artichoke](https://github.com/bgoonz/smart-artichoke)
- [https://bg-portfolio](https://bg-portfolio.netlify.app)

---

- [https://github.com/bgoonz/gatsby-starter-portfolio-cara](https://github.com/bgoonz/gatsby-starter-portfolio-cara)
- [https://sanity-gatsby-portfolio-3-studio-bit6zuzq](https://sanity-gatsby-portfolio-3-studio-bit6zuzq.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-portfolio3](https://github.com/bgoonz/sanity-gatsby-portfolio3)
- [https://sanity-gatsby-portfolio-3-web-4dmiq19t](https://sanity-gatsby-portfolio-3-web-4dmiq19t)
- [https://random-embedable-content](https://random-embedable-content.netlify.app)

---

- [https://github.com/bgoonz/random-list-of-embedable-content](https://github.com/bgoonz/random-list-of-embedable-content)
- [https://optimistic-curie-ddd352](https://optimistic-curie-ddd352.netlify.app)

---

- [https://github.com/bgoonz/yellowcake-mailchimp](https://github.com/bgoonz/yellowcake-mailchimp)
- [https://links4242](https://links4242.netlify.app)

---

- [https://github.com/bgoonz/Links-Shortcut-Site](https://github.com/bgoonz/Links-Shortcut-Site)
- [https://zen-bhabha-bd046f](https://zen-bhabha-bd046f.netlify.app)

---

- [https://github.com/bgoonz/Common-npm-Readme-Compilation](https://github.com/bgoonz/Common-npm-Readme-Compilation)
- [https://potluck-landing](https://potluck-landing.netlify.app)

---

- [https://github.com/bgoonz/terrific-dolphin](https://github.com/bgoonz/terrific-dolphin)
- [https://mihirbegmusiclab](https://mihirbegmusiclab.netlify.app)

---

- [https://github.com/bgoonz/MihirBegMusicLab](https://github.com/bgoonz/MihirBegMusicLab)
- [https://interesting-aspen-ce986](https://interesting-aspen-ce986.netlify.app)

---

- [https://github.com/bgoonz/interesting-aspen](https://github.com/bgoonz/interesting-aspen)
- [https://mihirbeg28](https://mihirbeg28.netlify.app)

---

- [https://github.com/bgoonz/panoramic-eggplant](https://github.com/bgoonz/panoramic-eggplant)
- [https://enthusiastic-tomato-a7ebc](https://enthusiastic-tomato-a7ebc)
- [https://hugo-cms-42](https://hugo-cms-42.netlify.app)

---

- [https://github.com/bgoonz/hugo-cms](https://github.com/bgoonz/hugo-cms)
- [https://bgoonz-cv](https://bgoonz-cv.netlify.app)

---

- [https://github.com/bgoonz/curious-eggplant](https://github.com/bgoonz/curious-eggplant)
- [https://exploring-next-sanity](https://exploring-next-sanity.netlify.app)

---

- [https://github.com/bgoonz/nervous-parsley](https://github.com/bgoonz/nervous-parsley)
- [https://adoring-carson-fac9fb](https://adoring-carson-fac9fb.netlify.app)

---

- [https://github.com/bgoonz/commercejs-nextjs-demo-store](https://github.com/bgoonz/commercejs-nextjs-demo-store)
- [https://kguner-fractions-website](https://kguner-fractions-website.netlify.app)

---

- [https://github.com/Web-Dev-Collaborative/fractions-visualizations-n-resources](https://github.com/Web-Dev-Collaborative/fractions-visualizations-n-resources)
- [https://quirky-meninsky-4181b5](https://quirky-meninsky-4181b5.netlify.app)

---

- [https://github.com/side-projects-42/DS-Bash-Examples-Deploy](https://github.com/side-projects-42/DS-Bash-Examples-Deploy)
- [https://starter-520d2](https://starter-520d2.netlify.app)

---

- [https://github.com/bgoonz/starter](https://github.com/bgoonz/starter)
- [https://bg-resume](https://bg-resume.netlify.app)

---

- [https://github.com/bgoonz/html-resume](https://github.com/bgoonz/html-resume)
- [https://portfolio42](https://portfolio42.netlify.app)

---

- [https://github.com/bgoonz/bgoonz.github.io](https://github.com/bgoonz/bgoonz.github.io)
- [https://objective-rosalind-d4ff71](https://objective-rosalind-d4ff71.netlify.app)

---

- [https://github.com/bgoonz/blog-research](https://github.com/bgoonz/blog-research)
- [https://hungry-shaw-30d504](https://hungry-shaw-30d504)
- [https://wonderful-pasteur-392fbe](https://wonderful-pasteur-392fbe.netlify.app)

---

- [https://github.com/bgoonz/norwex-react](https://github.com/bgoonz/norwex-react)
- [https://romantic-hamilton-514b79](https://romantic-hamilton-514b79.netlify.app)

---

- [https://github.com/bgoonz/Cumulative-Resource-List](https://github.com/bgoonz/Cumulative-Resource-List)
- [https://stupefied-wilson-2bc726](https://stupefied-wilson-2bc726.netlify.app)

---

- [https://github.com/bgoonz/react-web-anki-flash-cards](https://github.com/bgoonz/react-web-anki-flash-cards)
- [https://upbeat-mayer-92c10b](https://upbeat-mayer-92c10b.netlify.app)

---

- [https://github.com/bgoonz/ecommerce-react](https://github.com/bgoonz/ecommerce-react)
- [https://modest-booth-4e17df](https://modest-booth-4e17df.netlify.app)

---

- [https://github.com/bgoonz/Medium_Articles](https://github.com/bgoonz/Medium_Articles)
- [https://blog-v42-31eba](https://blog-v42-31eba.netlify.app)

---

- [https://github.com/bgoonz/blog-v42](https://github.com/bgoonz/blog-v42)
- [https://goofy-curran-95aa66](https://goofy-curran-95aa66.netlify.app)

---

- [https://github.com/bgoonz/gatsby-netlify-cms](https://github.com/bgoonz/gatsby-netlify-cms)
- [https://react-blog-1](https://react-blog-1.netlify.app)

---

- [https://github.com/bgoonz/React-Practice](https://github.com/bgoonz/React-Practice)
- [https://mihirbegmusic](https://mihirbegmusic.netlify.app)

---

- [https://github.com/bgoonz/Mihir_Beg_Final](https://github.com/bgoonz/Mihir_Beg_Final)
- [https://bgoonz-games](https://bgoonz-games.netlify.app)

---

- [https://github.com/bgoonz/Games](https://github.com/bgoonz/Games)
- [https://py-prac-42](https://py-prac-42.netlify.app)

---

- [https://github.com/bgoonz/PYTHON_PRAC](https://github.com/bgoonz/PYTHON_PRAC)
- [https://synth-music-theory](https://synth-music-theory.netlify.app)

---

- [https://github.com/bgoonz/Music-Theory-n-Web-Synth-Keyboard](https://github.com/bgoonz/Music-Theory-n-Web-Synth-Keyboard)
- [https://admiring-montalcini-965c0b](https://admiring-montalcini-965c0b.netlify.app)

---

- [https://github.com/bgoonz/Standalone-Metranome](https://github.com/bgoonz/Standalone-Metranome)
- [https://sanity-gatsby-blog-3-studio-ch48ysi1](https://sanity-gatsby-blog-3-studio-ch48ysi1.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog3](https://github.com/bgoonz/sanity-gatsby-blog3)
- [https://jovial-agnesi-8ec8b1](https://jovial-agnesi-8ec8b1.netlify.app)

---

- [https://github.com/bgoonz/mini-project-showcase](https://github.com/bgoonz/mini-project-showcase)
- [https://ternary42](https://ternary42.netlify.app)

---

- [https://github.com/bgoonz/Ternary-converter](https://github.com/bgoonz/Ternary-converter)
- [https://fourm-builder-gui](https://fourm-builder-gui.netlify.app)

---

- [https://github.com/bgoonz/form-builder-vanilla-js](https://github.com/bgoonz/form-builder-vanilla-js)
- [https://lambda-prep](https://lambda-prep.netlify.app)

---

- [https://github.com/bgoonz/lambda-prep](https://github.com/bgoonz/lambda-prep)
- [https://sanity-kitchen-sink-5-studio-9hogian6](https://sanity-kitchen-sink-5-studio-9hogian6)
- [https://ds-unit-5-lambda](https://ds-unit-5-lambda)
- [https://hopeful-shockley-150bee](https://hopeful-shockley-150bee.netlify.app)

---

- [https://github.com/bgoonz/Potluck-Planner](https://github.com/bgoonz/Potluck-Planner)
- [https://sidebar-blog](https://sidebar-blog.netlify.app)

---

- [https://github.com/side-projects-42/friendly-panda](https://github.com/side-projects-42/friendly-panda)
- [https://cheatsheets42](https://cheatsheets42)
- [https://silly-lichterman-b22b5f](https://silly-lichterman-b22b5f)
- [https://learning-redux42](https://learning-redux42)
- [https://project-portfolio42](https://project-portfolio42.netlify.app)

---

- [https://github.com/bgoonz/curious-zebra](https://github.com/bgoonz/curious-zebra)
- [https://splendid-onion-b0ec3](https://splendid-onion-b0ec3.netlify.app)

---

- [https://github.com/stackbit-projects/splendid-onion-b0ec3](https://github.com/stackbit-projects/splendid-onion-b0ec3)
- [https://bgoonzblog20-redo](https://bgoonzblog20-redo.netlify.app)

---

- [https://github.com/bgoonz/modern-triceratops](https://github.com/bgoonz/modern-triceratops)
- [https://hardcore-hamilton-c5b45e](https://hardcore-hamilton-c5b45e.netlify.app)

---

- [https://github.com/my-lambda-projects/peer](https://github.com/my-lambda-projects/peer)
- [https://curious-rabbit-f33af](https://curious-rabbit-f33af.netlify.app)

---

- [https://github.com/stackbit-projects/curious-rabbit-f33af](https://github.com/stackbit-projects/curious-rabbit-f33af)
- [https://kind-petunia-e8f9f](https://kind-petunia-e8f9f.netlify.app)

---

- [https://github.com/bgoonz/kind-petunia](https://github.com/bgoonz/kind-petunia)
- [https://elite-cabbage-3551b](https://elite-cabbage-3551b.netlify.app)

---

- [https://github.com/bgoonz/elite-cabbage](https://github.com/bgoonz/elite-cabbage)
- [https://norwex-next-js](https://norwex-next-js.netlify.app)

---

- [https://github.com/bgoonz/commercejs-nextjs-demo-store](https://github.com/bgoonz/commercejs-nextjs-demo-store)
- [https://sanity-gatsby-portfolio-studio-89chyji1](https://sanity-gatsby-portfolio-studio-89chyji1.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-portfolio](https://github.com/bgoonz/sanity-gatsby-portfolio)
- [https://sanity-gatsby-blog-studio-m195df5o](https://sanity-gatsby-blog-studio-m195df5o.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog](https://github.com/bgoonz/sanity-gatsby-blog)
- [https://sanity-translation-examples-studio-u93wc5ox](https://sanity-translation-examples-studio-u93wc5ox.netlify.app)

---

- [https://github.com/bgoonz/sanity-translation-examples](https://github.com/bgoonz/sanity-translation-examples)
- [https://sanity-catalyst-studio-njajg3jt](https://sanity-catalyst-studio-njajg3jt.netlify.app)

---

- [https://github.com/bgoonz/sanity-catalyst](https://github.com/bgoonz/sanity-catalyst)
- [https://sanity-catalyst-web-1zjgvx2t](https://sanity-catalyst-web-1zjgvx2t)
- [https://sanity-nuxt-events-studio-zd46wiji](https://sanity-nuxt-events-studio-zd46wiji.netlify.app)

---

- [https://github.com/bgoonz/sanity-nuxt-events](https://github.com/bgoonz/sanity-nuxt-events)
- [https://sad-ramanujan-235384](https://sad-ramanujan-235384)
- [https://gitlab.com/bryan.guner.dev/starter-hugo-online-course](https://gitlab.com/bryan.guner.dev/starter-hugo-online-course)
- [https://vibrant-noether-dbe366](https://vibrant-noether-dbe366.netlify.app)

---

- [https://github.com/bgoonz/jamstack-comments-engine](https://github.com/bgoonz/jamstack-comments-engine)
- [https://objective-torvalds-1c12dd](https://objective-torvalds-1c12dd.netlify.app)

---

- [https://github.com/bgoonz/jamstack-comments-engine1](https://github.com/bgoonz/jamstack-comments-engine1)
- [https://friendly-poincare-a11e2f](https://friendly-poincare-a11e2f.netlify.app)

---

- [https://github.com/bgoonz/jamstack-comments-engine2](https://github.com/bgoonz/jamstack-comments-engine2)
- [https://sanity-gatsby-blog-4-studio-p6qrh84r](https://sanity-gatsby-blog-4-studio-p6qrh84r.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog4](https://github.com/bgoonz/sanity-gatsby-blog4)
- [https://festive-kilby-f0a784](https://festive-kilby-f0a784)
- [https://gitlab.com/bryan.guner.dev/one-click-hugo-cms](https://gitlab.com/bryan.guner.dev/one-click-hugo-cms)
- [https://keen-williams-48be7c](https://keen-williams-48be7c)
- [https://gitlab.com/bryan.guner.dev/algo-prac](https://gitlab.com/bryan.guner.dev/algo-prac)
- [https://bgoonzgist](https://bgoonzgist)
- [https://resourcerepo2](https://resourcerepo2)
- [https://sanity-gatsby-blog-4-web-mobyn8k4](https://sanity-gatsby-blog-4-web-mobyn8k4.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog4](https://github.com/bgoonz/sanity-gatsby-blog4)
- [https://festive-elion-13b19c](https://festive-elion-13b19c.netlify.app)

---

- [https://github.com/bgoonz/nextjs-netlify-blog-template2](https://github.com/bgoonz/nextjs-netlify-blog-template2)
- [https://sanity-nuxt-events-web-i78cd7mw](https://sanity-nuxt-events-web-i78cd7mw.netlify.app)

---

- [https://github.com/bgoonz/sanity-nuxt-events](https://github.com/bgoonz/sanity-nuxt-events)
- [https://sanity-gatsby-blog-web-skwx3b17](https://sanity-gatsby-blog-web-skwx3b17.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-blog](https://github.com/bgoonz/sanity-gatsby-blog)
- [https://sanity-gatsby-portfolio-web-1wwhtk8k](https://sanity-gatsby-portfolio-web-1wwhtk8k.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-portfolio](https://github.com/bgoonz/sanity-gatsby-portfolio)
- [https://sanity-gatsby-hey-sugar-5](https://sanity-gatsby-hey-sugar-5.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-hey-sugar5](https://github.com/bgoonz/sanity-gatsby-hey-sugar5)
- [https://unruffled-bhabha-2ea500](https://unruffled-bhabha-2ea500.netlify.app)

---

- [https://github.com/bgoonz/commercejs-nextjs-demo-store42](https://github.com/bgoonz/commercejs-nextjs-demo-store42)
- [https://bgoonzblog20-backup](https://bgoonzblog20-backup.netlify.app)

---

- [https://github.com/bgoonz/BGOONZBLOG2.0STABLE](https://github.com/bgoonz/BGOONZBLOG2.0STABLE)
- [https://wizardly-hermann-c9ade8](https://wizardly-hermann-c9ade8.netlify.app)

---

- [https://github.com/bgoonz/nextjs-netlify-blog-template](https://github.com/bgoonz/nextjs-netlify-blog-template)
- [https://sanity-kitchen-sink-5-web](https://sanity-kitchen-sink-5-web.netlify.app)

---

- [https://github.com/bgoonz/sanity-kitchen-sink5](https://github.com/bgoonz/sanity-kitchen-sink5)
- [https://iframeshowcase](https://iframeshowcase.netlify.app)

---

- [https://github.com/bgoonz/iframe-showcase](https://github.com/bgoonz/iframe-showcase)
- [https://friendly-amaranth-51833](https://friendly-amaranth-51833.netlify.app)

---

- [https://github.com/bgoonz/friendly-amaranth](https://github.com/bgoonz/friendly-amaranth)
- [https://sanity-kitchen-sink-web-geaa75ie](https://sanity-kitchen-sink-web-geaa75ie.netlify.app)

---

- [https://github.com/bgoonz/sanity-kitchen-sink](https://github.com/bgoonz/sanity-kitchen-sink)
- [https://lambda-resources](https://lambda-resources.netlify.app)

---

- [https://github.com/bgoonz/Lambda](https://github.com/bgoonz/Lambda)
- [https://bgoonzblog30](https://bgoonzblog30.netlify.app)

---

- [https://github.com/bgoonz/bgoonzblog3.0](https://github.com/bgoonz/bgoonzblog3.0)
- [https://sanity-commercelayer-web-56265s29](https://sanity-commercelayer-web-56265s29.netlify.app)

---

- [https://github.com/bgoonz/sanity-commercelayer](https://github.com/bgoonz/sanity-commercelayer)
- [https://sanity-kitchen-sink-studio-us5ymc5z](https://sanity-kitchen-sink-studio-us5ymc5z.netlify.app)

---

- [https://github.com/bgoonz/sanity-kitchen-sink](https://github.com/bgoonz/sanity-kitchen-sink)
- [https://sanity-commercelayer-1-studio-rkmntw55](https://sanity-commercelayer-1-studio-rkmntw55.netlify.app)

---

- [https://github.com/bgoonz/sanity-commercelayer1](https://github.com/bgoonz/sanity-commercelayer1)
- [https://sanity-commercelayer-1-web](https://sanity-commercelayer-1-web)
- [https://sanity-gatsby-hey-sugar-studio-rkg94h5e](https://sanity-gatsby-hey-sugar-studio-rkg94h5e.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-hey-sugar](https://github.com/bgoonz/sanity-gatsby-hey-sugar)
- [https://sanity-gatsby-hey-sugar-web-666eqtdv](https://sanity-gatsby-hey-sugar-web-666eqtdv)
- [https://sanity-gatsby-hey-sugar-2-web](https://sanity-gatsby-hey-sugar-2-web.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-hey-sugar2](https://github.com/bgoonz/sanity-gatsby-hey-sugar2)
- [https://sanity-gatsby-hey-sugar-2-studio-1dm9vw5o](https://sanity-gatsby-hey-sugar-2-studio-1dm9vw5o)
- [https://sanity-kitchen-sink-2-studio-71rv9mea](https://sanity-kitchen-sink-2-studio-71rv9mea.netlify.app)

---

- [https://github.com/bgoonz/sanity-kitchen-sink2](https://github.com/bgoonz/sanity-kitchen-sink2)
- [https://sanity-kitchen-sink-2-web-p1dc8gro](https://sanity-kitchen-sink-2-web-p1dc8gro)
- [https://sanity-jigsaw-blog-studio-mgk1nds9](https://sanity-jigsaw-blog-studio-mgk1nds9.netlify.app)

---

- [https://github.com/bgoonz/sanity-jigsaw-blog](https://github.com/bgoonz/sanity-jigsaw-blog)
- [https://sanity-jigsaw-blog-web-cy6y69s7](https://sanity-jigsaw-blog-web-cy6y69s7)
- [https://sanity-kitchen-sink-3-studio-qpaz93e3](https://sanity-kitchen-sink-3-studio-qpaz93e3.netlify.app)

---

- [https://github.com/bgoonz/sanity-kitchen-sink3](https://github.com/bgoonz/sanity-kitchen-sink3)
- [https://sanity-kitchen-sink-3-web-v2fb8vmv](https://sanity-kitchen-sink-3-web-v2fb8vmv)
- [https://sanity-gatsby-hey-sugar-5-studio](https://sanity-gatsby-hey-sugar-5-studio.netlify.app)

---

- [https://github.com/bgoonz/sanity-gatsby-hey-sugar5](https://github.com/bgoonz/sanity-gatsby-hey-sugar5)
- [https://nervous-swartz-0ab2cc](https://nervous-swartz-0ab2cc.netlify.app)

---

- [https://github.com/bgoonz/ecommerce-interactive](https://github.com/bgoonz/ecommerce-interactive)
- [https://recursion-prompts](https://recursion-prompts.netlify.app)

---

- [https://github.com/bgoonz/Live-htmlRendered-Mocha-Spec--Recursion-Practice](https://github.com/bgoonz/Live-htmlRendered-Mocha-Spec--Recursion-Practice)
- [https://clever-ramanujan-f9ce0a](https://clever-ramanujan-f9ce0a.netlify.app)

---

- [https://github.com/bgoonz/Lambda-Resource-Static-Assets](https://github.com/bgoonz/Lambda-Resource-Static-Assets)
- [https://gracious-raman-474030](https://gracious-raman-474030.netlify.app)

---

- [https://github.com/bgoonz/Data-Struc-Static](https://github.com/bgoonz/Data-Struc-Static)
- [https://pedantic-wing-adbf82](https://pedantic-wing-adbf82.netlify.app)

---

- [https://github.com/bgoonz/excel2html-table](https://github.com/bgoonz/excel2html-table)
- [https://happy-mestorf-0f8e75](https://happy-mestorf-0f8e75.netlify.app)

---

- [https://github.com/bgoonz/zumzi-chat-messenger](https://github.com/bgoonz/zumzi-chat-messenger)
- [https://live-form](https://live-form.netlify.app)

---

- [https://github.com/bgoonz/live-form](https://github.com/bgoonz/live-form)
- [https://trusting-aryabhata-e5438d](https://trusting-aryabhata-e5438d.netlify.app)

---

- [https://github.com/bgoonz/vscode-Extension-readmes](https://github.com/bgoonz/vscode-Extension-readmes)
- [https://jovial-keller-063835](https://jovial-keller-063835.netlify.app)

---

- [https://github.com/bgoonz/https___mihirbeg.com_](https://github.com/bgoonz/https___mihirbeg.com_)
- [https://web-dev-resource-hub](https://web-dev-resource-hub.netlify.app)

---

- [https://github.com/bgoonz/web-dev-notes-backup](https://github.com/bgoonz/web-dev-notes-backup)
- [https://flamboyant-northcutt-14b025](https://flamboyant-northcutt-14b025.netlify.app)

---

- [https://github.com/bgoonz/week-10-take-2](https://github.com/bgoonz/week-10-take-2)
- [https://bgoonzconnekt4](https://bgoonzconnekt4.netlify.app)

---

- [https://github.com/bgoonz/Connect-Four-Final-Version](https://github.com/bgoonz/Connect-Four-Final-Version)
- [https://thealgorithms](https://thealgorithms)
- [https://hardcore-lamport-7eb855](https://hardcore-lamport-7eb855.netlify.app)

---

- [https://github.com/bgoonz/nextjs-netlify-blog-template42](https://github.com/bgoonz/nextjs-netlify-blog-template42)
- [https://sanity-commercelayer-studio-nzbh7yx7](https://sanity-commercelayer-studio-nzbh7yx7)
- [https://python-playground42](https://python-playground42.netlify.app)

---

- [https://github.com/bgoonz/python-playground-embed](https://github.com/bgoonz/python-playground-embed)
- [https://elegant-goodall-566182](https://elegant-goodall-566182)
- [https://python-playground43](https://python-playground43)
- [https://scopeclosurecontext](https://scopeclosurecontext.netlify.app)

---

- [https://github.com/bgoonz/scope-closure-context](https://github.com/bgoonz/scope-closure-context)
- [https://meditate42app](https://meditate42app.netlify.app)

---

- [https://github.com/bgoonz/meditation-app](https://github.com/bgoonz/meditation-app)
- [https://site-analysis](https://site-analysis.netlify.app)

---

- [https://github.com/bgoonz/site-analysis](https://github.com/bgoonz/site-analysis)
- [https://tetris42](https://tetris42.netlify.app)

---

- [https://github.com/bgoonz/TetrisJS](https://github.com/bgoonz/TetrisJS)
- [https://githtmlpreview](https://githtmlpreview.netlify.app)

---

- [https://github.com/bgoonz/GIT-HTML-PREVIEW-TOOL](https://github.com/bgoonz/GIT-HTML-PREVIEW-TOOL)
- [https://devtools42](https://devtools42.netlify.app)

---

- [https://github.com/bgoonz/TexTools](https://github.com/bgoonz/TexTools)
- [https://project-showcase-bgoonz](https://project-showcase-bgoonz.netlify.app)

---

- [https://github.com/bgoonz/Project-Showcase](https://github.com/bgoonz/Project-Showcase)
- [https://code-playground](https://code-playground.netlify.app)

---

- [https://github.com/bgoonz/embedable-repl-and-integrated-code-space-playground](https://github.com/bgoonz/embedable-repl-and-integrated-code-space-playground)
- [https://condescending-lewin-c96727](https://condescending-lewin-c96727.netlify.app)

---

- [https://github.com/bgoonz/Revamped-Automatic-Guitar-Effect-Triggering](https://github.com/bgoonz/Revamped-Automatic-Guitar-Effect-Triggering)
- [https://oval-cabbage-354f6](https://oval-cabbage-354f6.netlify.app)

---

- [https://github.com/bgoonz/oval-cabbage](https://github.com/bgoonz/oval-cabbage)
- [https://web-dev-interview-prep-quiz-website](https://web-dev-interview-prep-quiz-website.netlify.app)

---

- [https://github.com/bgoonz/web-dev-interview-prep-quiz-website](https://github.com/bgoonz/web-dev-interview-prep-quiz-website)
- [https://priceless-shaw-86ccb2](https://priceless-shaw-86ccb2.netlify.app)

---

- [https://github.com/bgoonz/atlassian-templates](https://github.com/bgoonz/atlassian-templates)
