---
title: Mini Projects
excerpt: >-
    In this section you'll learn how to add syntax highlighting, examples,
    callouts and much more.
seo:
    title: Mini Projects
    description: This is the Mini Projects page
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Mini Projects
          keyName: property
        - name: 'og:description'
          value: This is the Mini Projects page
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Mini Projects
        - name: 'twitter:description'
          value: This is the Mini Projects page
template: docs
weight: 0
---


<br>
<hr>
<br>
<hr>
<br>
<h1> Random Embedable Content  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://random-list-of-embedable-content.vercel.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://futuristic-rosemary-d4acc.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://iframeshowcase.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>


<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://bgoonz.blogspot.com/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://www.youtube.com/embed/xGZSWvFess8" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://ds-unit-5-lambda.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://sanity-gatsby-blog-web-skwx3b17.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://kguner-fractions-website.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://dev-journal42.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://sanity-gatsby-hey-sugar-5.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://friendly-amaranth-51833.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://sidebar-blog.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://markdown-templates-42.netlify.app/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  " height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  " height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



<br>
<hr>
<br>
<hr>
<br>
<h1>  </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  " height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>

<br>
<hr>
<br>
<hr>
<br>
<h1>   </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="  " height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
                                                       
<br>
<br>

<hr>

<hr>
<br>



