---
title: Reference
weight: 0
excerpt: helpful reference guides
seo:
  title: ''
  description: ''
  robots: []
  extra: []
template: docs
---

# Reference:

- [SITEMAP🗺🟈]\(https://bgoonz-blog.netlify.app/docs/sitemap/)

# Bookmarks:

<iframe src="https://bgoonz-bookmarks.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

# SearchAwesome:

<iframe src="https://search-awesome.vercel.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>


# Job Search:

<iframe src="https://web-dev-collaborative.github.io/gitpod-job-search-html-static/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
