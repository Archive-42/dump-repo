---
title: Contact!
sections: []
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<br>
<br>

<iframe src="https://bgoonz-blog-v3-0.netlify.app/contact/" height="900px" width="100%">
</iframe>

<br>
<hr>
<br>

<hr>
<br>

<iframe src="https://comments-3.bgoonz.repl.co/" height="900px" width="100%">
</iframe>

### Calendar:

<iframe src="https://calendar.google.com/calendar/embed?src=c_f16bvhnsdsp8epckcinsu4978g%40group.calendar.google.com&ctz=America%2FNew_York" style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
