---
title: Trouble Shooting
weight: 0
excerpt: Here I will save details of problems I have been troubleshooting.
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<br>
<h1>  Trouble Shooting Log </h1>
<br>
<iframe width="900" height="1400" frameborder="0" scrolling="no" src="https://onedrive.live.com/embed?resid=D21009FDD967A241%21538628&authkey=%21AB8fPL3wSKz3AxU&em=2&AllowTyping=True&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True"></iframe>

<br>
<hr>
<br>

