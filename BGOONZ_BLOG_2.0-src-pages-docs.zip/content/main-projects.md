---
title: RECENT PROJECTS
weight: 0
excerpt: embedded utilities
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1>  Potluck Planner </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://potluck-landing.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<h1>Meditation App </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://meditate42app.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>

<h1>  Web Audio DAW      </h1>
<br>

<iframe src="https://mihirbeg28.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>

<h1>React & Shopify Ecommerce Site (Norwex)     </h1>
<br>

<iframe src="https://friendly-amaranth-51833.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<br>
<h1>Bgoonz Bookmarks   </h1>
<br>

<iframe src="https://bgoonzbookmarks.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>
<br>
<h1>Goal Tracker  </h1>
<br>

<iframe src="https://splendid-onion-b0ec3.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<hr>
<br>

