---
title: Docs
weight: 0
excerpt: Documentation
seo:
    title: Documentation
    description: Documentation
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<div
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>

<br>
<h1>My DevDocs Deploy</h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://devdecs42.herokuapp.com/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>

-   [/job-hunt/](https://bgoonz-blog.netlify.app/job-hunt/)
-   [/notes-template/](https://bgoonz-blog.netlify.app/notes-template/)
-   [/](https://bgoonz-blog.netlify.app/)
-   [/showcase/](https://bgoonz-blog.netlify.app/showcase/)
-   [/blog/](https://bgoonz-blog.netlify.app/blog/)
-   [/review/](https://bgoonz-blog.netlify.app/review/)
-   [/blog/blog-archive/](https://bgoonz-blog.netlify.app/blog/blog-archive/)
-   [/blog/my-medium/](https://bgoonz-blog.netlify.app/blog/my-medium/)
-   [/blog/blogwcomments/](https://bgoonz-blog.netlify.app/blog/blogwcomments/)
-   [/blog/data-structures/](https://bgoonz-blog.netlify.app/blog/data-structures/)
-   [/docs/gallery/](https://bgoonz-blog.netlify.app/docs/gallery/)
-   [/blog/python-for-js-dev/](https://bgoonz-blog.netlify.app/blog/python-for-js-dev/)
-   [/blog/platform-docs/](https://bgoonz-blog.netlify.app/blog/platform-docs/)
-   [/docs/sitemap/](https://bgoonz-blog.netlify.app/docs/sitemap/)
-   [/docs/about/me/](https://bgoonz-blog.netlify.app/docs/about/me/)
-   [/blog/python-resources/](https://bgoonz-blog.netlify.app/blog/python-resources/)
-   [/docs/about/resume/](https://bgoonz-blog.netlify.app/docs/about/resume/)
-   [/docs/](https://bgoonz-blog.netlify.app/docs/)
-   [/blog/web-scraping/](https://bgoonz-blog.netlify.app/blog/web-scraping/)
-   [/docs/about/](https://bgoonz-blog.netlify.app/docs/about/)
-   [/docs/articles/algo/](https://bgoonz-blog.netlify.app/docs/articles/algo/)
-   [/docs/articles/install/](https://bgoonz-blog.netlify.app/docs/articles/install/)
-   [/docs/articles/](https://bgoonz-blog.netlify.app/docs/articles/)
-   [/docs/articles/gallery/](https://bgoonz-blog.netlify.app/docs/articles/gallery/)
-   [/docs/articles/intro/](https://bgoonz-blog.netlify.app/docs/articles/intro/)
-   [/docs/articles/basic-web-dev/](https://bgoonz-blog.netlify.app/docs/articles/basic-web-dev/)
-   [/docs/articles/reading-files/](https://bgoonz-blog.netlify.app/docs/articles/reading-files/)
-   [/docs/articles/writing-files/](https://bgoonz-blog.netlify.app/docs/articles/writing-files/)
-   [/docs/audio/audio/](https://bgoonz-blog.netlify.app/docs/audio/audio/)
-   [/docs/content/projects/](https://bgoonz-blog.netlify.app/docs/content/projects/)
-   [/docs/audio/terms/](https://bgoonz-blog.netlify.app/docs/audio/terms/)
-   [/docs/faq/](https://bgoonz-blog.netlify.app/docs/faq/)
-   [/docs/community/](https://bgoonz-blog.netlify.app/docs/community/)
-   [/docs/articles/resources/](https://bgoonz-blog.netlify.app/docs/articles/resources/)
-   [/docs/content/](https://bgoonz-blog.netlify.app/docs/content/)
-   [/docs/docs/git-repos/](https://bgoonz-blog.netlify.app/docs/docs/git-repos/)
-   [/docs/content/trouble-shooting/](https://bgoonz-blog.netlify.app/docs/content/trouble-shooting/)
-   [/docs/articles/python/](https://bgoonz-blog.netlify.app/docs/articles/python/)
-   [/docs/interact/clock/](https://bgoonz-blog.netlify.app/docs/interact/clock/)
-   [/docs/docs/python/](https://bgoonz-blog.netlify.app/docs/docs/python/)
-   [/docs/interact/jupyter-notebooks/](https://bgoonz-blog.netlify.app/docs/interact/jupyter-notebooks/)
-   [/docs/interact/](https://bgoonz-blog.netlify.app/docs/interact/)
-   [/docs/faq/contact/](https://bgoonz-blog.netlify.app/docs/faq/contact/)
-   [/docs/quick-reference/docs/](https://bgoonz-blog.netlify.app/docs/quick-reference/docs/)
-   [/docs/interact/other-sites/](https://bgoonz-blog.netlify.app/docs/interact/other-sites/)
-   [/docs/quick-reference/new-repo-instructions/](https://bgoonz-blog.netlify.app/docs/quick-reference/new-repo-instructions/)
-   [/docs/quick-reference/Emmet/](https://bgoonz-blog.netlify.app/docs/quick-reference/Emmet/)
-   [/docs/quick-reference/installation/](https://bgoonz-blog.netlify.app/docs/quick-reference/installation/)
-   [/docs/quick-reference/vscode-themes/](https://bgoonz-blog.netlify.app/docs/quick-reference/vscode-themes/)
-   [/docs/react/createReactApp/](https://bgoonz-blog.netlify.app/docs/react/createReactApp/)
-   [/docs/react/react2/](https://bgoonz-blog.netlify.app/docs/react/react2/)
-   [/docs/quick-reference/](https://bgoonz-blog.netlify.app/docs/quick-reference/)
-   [/docs/react/](https://bgoonz-blog.netlify.app/docs/react/)
-   [/docs/tools/](https://bgoonz-blog.netlify.app/docs/tools/)
-   [/docs/tools/notes-template/](https://bgoonz-blog.netlify.app/docs/tools/notes-template/)
-   [/docs/tools/more-tools/](https://bgoonz-blog.netlify.app/docs/tools/more-tools/)
-   [/docs/tools/plug-ins/](https://bgoonz-blog.netlify.app/docs/tools/plug-ins/)
-   [/docs/articles/node/install/](https://bgoonz-blog.netlify.app/docs/articles/node/install/)
-   [/docs/tools/vscode/](https://bgoonz-blog.netlify.app/docs/tools/vscode/)
-   [/docs/articles/node/intro/](https://bgoonz-blog.netlify.app/docs/articles/node/intro/)
-   [/docs/articles/node/nodejs/](https://bgoonz-blog.netlify.app/docs/articles/node/nodejs/)
-   [/docs/articles/node/nodevsbrowser/](https://bgoonz-blog.netlify.app/docs/articles/node/nodevsbrowser/)
-   [/docs/articles/node/npm/](https://bgoonz-blog.netlify.app/docs/articles/node/npm/)
-   [/docs/articles/node/reading-files/](https://bgoonz-blog.netlify.app/docs/articles/node/reading-files/)
-   [/docs/articles/node/writing-files/](https://bgoonz-blog.netlify.app/docs/articles/node/writing-files/)
-   [/docs/react-in-depth/](https://bgoonz-blog.netlify.app/docs/react-in-depth/)
-   [/docs/articles/article-compilation/](https://bgoonz-blog.netlify.app/docs/articles/article-compilation/)
-   [/docs/medium/my-websites/](https://bgoonz-blog.netlify.app/docs/medium/my-websites/)
-   [/docs/medium/social/](https://bgoonz-blog.netlify.app/docs/medium/social/)
-   [/docs/medium/medium-links/](https://bgoonz-blog.netlify.app/docs/medium/medium-links/)
-   [/docs/medium/](https://bgoonz-blog.netlify.app/docs/medium/)
