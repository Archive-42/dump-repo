---
title: lorem-ipsum
weight: 0
excerpt: lorem-ipsum
seo:
    title: ''
    description: ''
    robots: []
    extra: []
template: docs
---

## A - C&#xA;&#xA;

-   [Ableton](https://www.ableton.com/en/about) | Berlin, Germany | Take-home programming task (discussed via Skype), then pair programming and debugging session on-site

-   [Abstract](https://angel.co/abstract/jobs) | San Francisco, CA

-   [Accenture](https://www.accenture.com/us-en/careers) | San Francisco, CA / Los Angeles, CA / New York, NY | Technical phone discussion with architecture manager, followed by behavioral interview focusing on soft skills

-   [Accredible](https://www.accredible.com/careers) | Cambridge, UK / San Francisco, CA / Remote | Take home project, then a pair-programming and discussion onsite / Skype round.

-   [Acko](https://acko.com/) | Mumbai, India | Phone interview, followed by a small take home problem. Finally a F2F or skype pair programming session

-   [Acumen](http://www.acumenci.com/joinourteam) | London, UK | Small take home test, and sit in on some sprint rituals on-site

-   [Addstones](https://www.addstones.com/) | Paris, FR / Singapore, SG / Bucharest, RO / London, UK | Multiple interviews, discussion of technical background and experiences. Sometimes we do a on-site unsupervised small exercise.

-   [Adnymics](https://adnymics.com/) | Munich, DE | Take home project, then work with the team for a day

-   [Adthena](http://adthena.com/) | London, UK | Takehome project and discussion on-site

-   [AdWyze](https://angel.co/adwyze/jobs) | Bangalore, India | Short takehome project + (for fulltime) onsite pairing

-   [AeroFS](https://www.aerofs.com/company/careers) | San Francisco, CA | Short takehome project + phone interview

-   [Affinity](https://affinity.recruiterbox.com/#content) | San Francisco, CA | Implementation of a children's game, then take-home project OR real-world design questions

-   [Ageno](https://ageno.pl/) | Bielsko-Biala, Poland | Simple Magento Take-home project and discussion on the real world problems.

-   [AgileMD](https://angel.co/agilemd/jobs) | San Francisco, CA | Takehome project

-   [Agoda](https://careersatagoda.com/departments/technology) | Bangkok, Thailand | Take-home project, then a discussion onsite round.

-   [Agrilyst](https://agrilyst.com/) | New York, NY / Remote | Short takehome project & remote pairing

-   [Airbrake](https://airbrake.io/) | San Francisco, CA / Remote | Take-home project & pair on a problem similar to daily work

-   [Aiwip](http://aiwip.com/) | London, UK | Skype/phone interview followed by takehome project or worksample (or whiteboard)

-   [Ajira](http://ajira.tech/) | Chennai, India / Austin, TX | Take home project, then pair programming, technical discussions, cultural fit

-   [Algolia](https://www.algolia.com/careers) | Paris, France / San Francisco, CA | Takehome project & Onsite discussions and presentation

-   [all about apps GmbH](https://www.allaboutapps.at/jobs) | Vienna, Austria | 2-phase technical discussion & examination with department heads and management.

-   [Allegro](https://allegro.pl/praca) | Warsaw, Poland; Poznan, Poland; Torun, Poland; Wroclaw, Poland; Krakow, Poland | Take home, simple project. Series of 2 technical interviews (how to build things, how to solve specific, real world problem) and meeting with a team leader.

-   [Alluvium](https://alluvium.io/) | Brooklyn, NY | Take-home assignment, on-site review dovetailing into collaborative project planning for extension.

-   [AlphaSights](https://engineering.alphasights.com/) | London, UK / New York, NY / Remote | Initial interview, pair programming then final round with general technical questions

-   [AMAGI](https://amagi.io/) | Makati, Philippines | 1) Review of your resume, portfolio, and/or GitHub profile; 2) 1 hour discussion (in-person or Skype) about your goals, experience, personal culture, and how to apply technical solutions to real problems;

-   [Analytical Flavor Systems](https://gastrograph.com/) | Manhattan, New York | Code sample or take-home project, both with discussion.

-   [Apollo Agriculture](https://apolloagriculture.com/) | Nairobi, Kenya/Remote | Takehome project or Worksample (or whiteboard)

-   [Applied](https://www.beapplied.com/) | London, UK | Situational judgement tests focusing on real-world soft skills (online then in structured interview)

-   [Arachnys](https://angel.co/arachnys/jobs/220465-software-engineer) | London, UK | Take home test, real world pair programming

-   [Articulate](https://articulate.com/company/careers) | Remote | Take-home project & pair program on a problem similar to daily work

-   [Artsy](https://www.artsy.net/jobs#engineering) | New York, NY / London, UK / Berlin, Germany / Los Angeles, CA / Hong Kong, Hong Kong / Remote | Our process: 1) Informal chat 2) Application 3) Phone screen 4) In-person interview with 1 lead, 2 individual contributors and 1 non-engineer (30-45 mins each), focusing on your work habits and expertise as demonstrated in your previous work 5) ~4 in-depth professional reference calls (30-45 mins each).

-   [ASI Data Science](https://www.asidatascience.com/careers) | London, UK | Project to work at home, general technical questions, pair programming with engineers

-   [ASOS](https://jobs.asos.com/epostings/index.cfm?fuseaction=app.jobsearch&company_id=30071&version=1&byBusinessUnit=5) | London, UK | Take home or in-person code refactoring exercise, in-person walk-though of solution including software crafstmanship principles and design decisions, in-person freestyle architecture walk-through

-   [Ataccama](https://jobs.ataccama.com/) | Prague, Czech Republic | Face to face interview (skype or onsite), coding task for 30 min, meeting with team members

-   [aTech Media](https://atech.media/) | London, UK | Face to face interview, review of existing open source contributions or, if none are available, asked to write a library for something that interests them

-   [Aura Frames](https://auraframes.com/jobs?gh_src=2ef5cfa32) | New York, NY / San Francisco, CA | Simplified real-world coding task on Coderpad.io, followed by a few hours onsite writing code in our actual codebase.

-   [Aurora Solar](https://www.aurorasolar.com/careers) | San Francisco, CA | Our process: 1) Initial phone call 2) 1 hour take home project in CoderPad along with a few essay questions relating to JavaScript, testing, etc. 3) Remote pairing session solving a problem similar to day to day work. 4) In-person interview with additional pairing exercise done on a laptop as well as culture interviews.

-   [Auth0](https://auth0.com/blog/how-we-hire-engineers) | Bellevue, WA / Buenos Aires, Argentina / Remote | Series of interviews, go over technical background and past experiences, take-home project

-   [Auto1](https://www.auto1-group.com/jobs) | Berlin, DE | Series of Skype interviews which covers general technical questions, followed by a take-home assignment

-   [Automattic](https://automattic.com/work-with-us) | Remote | short take-home real-world task, then a few weeks-long real-world, part-time, and paid project on production code

-   [AutoScout24](https://github.com/AutoScout24/hiring) | Munich, Germany | Skype interview followed by home assignment from our day-to-day business and then on-site interview including lunch with a team

-   [Avant](https://avant.com/jobs) | Chicago, IL | Pair programming interviews.

-   [Avarteq GmbH](https://www.avarteq.com/career) | Berlin, Germany / Saarbrücken, Germany | Technical interview with our developers on-site or remote followed by a work sample in a pair programming session or a previous take-home project with a follow-up discussion and detailed feedback.

-   [Avocarrot](https://www.avocarrot.com/company) | Athens, Greece | on-site real world problem discussion and pair programming

-   [Axelerant](https://www.axelerant.com/careers) | Remote | Take-home project, interviews with hr and engineering team.

-   [Axiacore](https://axiacore.com/) | Bogota, Colombia | We talk about on how is your process when solving problems.

-   [Axios](https://www.axios.com/about#jobs) | Arlington, VA / New York, NY / San Francisco, CA / Remote | Take-home project, with discussion.

-   [B12](https://boards.greenhouse.io/b12#.WMlLfRIrJTa) | New York, NY | Take-home exercises and pair-programming with the team.

-   [B2W Digital](http://somos.b2wdigital.com/bit) | Rio de Janeiro, Brazil; São Paulo, Brazil | Time-boxed coding exercise at home, on-site pair programming with engineers and live software architecture challenges based on real situations.

-   [Babylon Health iOS Team](https://github.com/Babylonpartners/iOS-Interview-Demo) | London, UK | Take-home project, on-site presentation and discussion, design and product interview.

-   [Backbase](http://careers.backbase.com/) | Amsterdam, Netherlands; Cardiff, Wales; London, UK; Atlanta, GA | Takehome project, interviews

-   [Badi](https://jobs.badi.com/) | Barcelona, Spain | Phone Screen, Take-home project, then a discussion onsite round.

-   [Badoo](https://team.badoo.com/jobs) | London, UK | Take-home project, then a discussion onsite round.

-   [BAE Systems Applied Intelligence](https://career012.successfactors.eu/sfcareer/jobreqcareer?jobId=46145&company=BAE) | London, UK | Initial interview with experience based technical questions, second interview pair programming on problem similar to daily work

-   [Bakken & Bæck](https://bakkenbaeck.com/jobs) | Oslo, Norway; Amsterdam, Netherlands; Bonn, Germany | Skype interview followed by take-home assignment and a visit to one of our offices

-   [Balabit](https://career.balabit.com/) | Budapest, Hungary | Take-home project (medium size, with restrictions, e.g. only stdlib may be used), then discussion on-site

-   [Barracuda View Team](https://www.barracuda.com/company/careers) | Chelmsford, MA / Remote | Phone screen, remote pair programming session, technical discussion interview, culture fit interview

-   [Basecamp](https://basecamp.com/about/jobs) | Chicago, IL / Remote

-   [Beam Dental](https://beam.dental/jobs) | Columbus, OH | Phone Screen, Take Home Project, In-Person Pairing and Cross-Functional Interview

-   [Belka](http://belka.us/lavora-con-no) | Trento, Italy; Munich, Germany | We give you a small task that you can do alone and then we evaluate your work with you

-   [Bemind Interactive](https://bemind.recruitee.com/) | Biella, Italy / Latina, Italy / Remote | Series of interviews, discussion about technical background and past experiences, take-home project & pair programming

-   [Bendyworks](https://bendyworks.com/careers) | Madison, WI | Interviews and pair programming on personal projects

-   [Betterment](https://www.betterment.com/careers) | New York, NY | Phone interview followed by on-site pair programming to simulate a Betterment feature build.

-   [BetterPT](https://www.betterpt.com/) | New York, NY | Initial phone interview, project using our tech stack, on-site code review/pair programming and "meet the team".

-   [Big Nerd Ranch](https://www.bignerdranch.com/about/careers) | Atlanta, GA & Remote | Interviews and pair programming on an internal project or problem.

-   [BioConnect](https://www.bioconnect.com/company/careers) | Toronto, Canada | Take-home assignment & discussion

-   [bitExpert AG](https://www.bitexpert.de/karriere) | Mannheim, Germany | Interview with experience based technical questions

-   [Bits of Love](https://www.bitsoflove.be/careers) | Bruges, Belgium | In-person interview to evaluate experience and motivation, potentially followed by take-home project.

-   [Blackdot Solutions](http://blackdotsolutions.com/) | Cambridge, UK | Take-home project followed by on-site face-to-face walkthru of your code focusing on decisions/reasoning/technology used.

-   [Bleacher Report](http://bleacherreport.com/) | San Francisco, CA, USA | Take-home project; on-site discussion about the project and meeting with different teams

-   [Blendle](https://blendle.homerun.co/?lang=en) | Utrecht, The Netherlands | Take-home project & pair program on a problem similar to daily work

-   [blogfoster](https://github.com/blogfoster/join-the-engineering-team) | Berlin, Germany | Take-home project, discussion on-site

-   [Blue Bottle Coffee](https://www.bluebottlecoffee.com/careers) | Oakland, CA | Technical Phone Screen, Take Home Challenge, Technical in-persons.

-   [Bluesoft](http://www.bluesoft.com.br/) | São Paulo, Brazil | Takehome project and an interview to evaluate the candidate's previous experience.

-   [Bocoup](https://bocoup.com/careers) | Boston, MA / Remote | Pair programming with personal laptop on typical problem seen at work

-   [Bolste](http://careers.bolste.com/) | Phoenix, AZ | Conversational in-person interviews with team members and pair programming through real world problems

-   [BookingSync](https://www.bookingsync.com/en/jobs) | Remote | Small takehome project, interviews over skype with team members.

-   [BoomTown](http://boomtownroi.com/) | Charleston, SC / Atlanta, GA / Remote | Conversational in-person interviews with potential team members and managers that revolve around past experience and how that could be applied to future work

-   [Bouvet](http://www.bouvet.no/) | Bergen, Norway | Pair programming with senior engineers

-   [brainn.co](https://brainn.co/) | São Paulo, BR | Zoom/On-site interview, take-home project and interview with a team leader.

-   [BrainStation-23](http://brainstation-23.com/) | Dhaka, BD | A practical project followed by series of in-person interview sessions

-   [Breather](https://breather.com/jobs) | Montreal, Canada | Series of interviews including a conversation about the candidate's experience and a technical discussion involving real world problems

-   [BrightBytes](http://www.brightbytes.net/careers) | San Francisco, CA | Time-boxed coding exercise at home and on-site pair programming with engineers

-   [BrightHR](https://www.brighthr.com/careers) | Manchester, UK | Telephone conversation, coding exercise at home, on-site pairing with a cultural interview, meet the team.

-   [brightwheel](https://angel.co/brightwheel/jobs) | San Francisco, CA | Take home exercise, and systems design.

-   [Broad Institute's Data Sciences Platform](https://www.broadinstitute.org/data-sciences-platform) | Cambridge, MA | Phone screen, small take home project, both a technical and non-technical discussion panel, and a panel following up on the take home project walking through the solution and making a modification to the original code

-   [Bubblin Superbooks](https://www.bubbl.in/about) | Remote | View code, projects, libraries or any other open source story that you have been a part of, a small take-home project with real code occasionally.

-   [Buffer](https://buffer.com/journey) | Remote | Interviews over video call, code walkthrough of real code focussing on decisions and reasoning, then a 45 day full time, fully paid contract project working on production code.

-   [Bugcrowd](https://www.bugcrowd.com/about/careers/) | San Francisco, CA / Sydney, NSW | Take home exercise, half-day onsite walking through code, and pair programming.

-   [Buhler Group](http://www.buhlergroup.com/) | Prague, CZ | Interview with a couple of technical questions. No task needed. Depending on the team there is another round with the guys in the HQ via skype.

-   [Bulb](https://www.bulb.co.uk/) | London, UK | Phone screening, followed by a 2-4 hours take home task. If successful, on-site interview to discuss and extend with the reviewer and one other engineer, followed by 2x informal "Meet the team" interviews.

-   [Busbud](https://www.busbud.com/en/careers) | Montreal, Canada | Phone screening, followed by a 2-4 hours take home assignment. If the challenge is a success, on-site or remote interview with team members, including someone who reviewed it, to talk about it and potential next steps if the challenge was a real life task.

-   [Bustle](https://www.bustle.com/labs) | New York City, Ny / Remote | Half day pair programming on a task for production or one of our Open Source projects. We'll also buy you lunch with the team.

-   [busuu](https://www.busuu.com/jobs) | London, UK | Video call to show real code as first stage. In office pair programming, white board real world problem that we've encountered before, and history/experience discussion.

-   [ButterCMS](https://buttercms.com/) | Chicago, IL; Remote | Take home exercise and half-day of pair programming

-   [ByBox](https://www.bybox.com/company/careers/) | Remote | Phone interview followed by interview with devs (ideally in person but sometimes Skype) covering technical experience and coding exercise with real code.

-   [CACI Rome](http://careers.caci.com/ListJobs/All/Search/location/rome/state/ny/country/us) | Rome, NY; Remote | Phone interview followed by in-person or Skype screen sharing interview with a coding exercise in either Java, web (Node.js + frontend), or both. Interview format is exclusive to the Rome, NY office and may not be shared by other regional CACI offices.

-   [Cake Solutions](http://www.cakesolutions.net/careers) | Manchester, UK; London, UK; New York, NY | Skype / Hangouts / phone call to explain the technical background, current position and set expectations about the salary, relocation, etc; if all good, what to expect next. Then take-home exercise for roughly 4 hours to demonstrate good thinking and ability to pick up new things, explain & document the solution, finishing with pair programming with senior developers (remote or in person); use the code as a talking point around the more difficult things after getting through the simple starter tasks.

-   [Capgemini UK Java Team](https://www.uk.capgemini.com/) | London, UK; Woking, UK; Bristol, UK; Cardiff, Wales; Birmingham, UK; Manchester, UK; Leeds, UK; Rotherham, UK; Liverpool, UK; Newcastle, UK; Edinburgh, Scotland; Glasgow, Scotland | Technical telephone interview (30 minutes), take-home non-CompSci coding exercise (3-4 hours), face-to-face role-played consulting scenario involving a solution architecture and a delivery plan (two hours)

-   [Caravelo](http://www.caravelo.com/softdev) | Barcelona, Spain | Take home project, then technical discussion about the code in-person or Skype and hang out with the team.

-   [Cartegraph](http://www.cartegraph.com/company/careers/) | Dubuque, IA / Remote | Phone screen, hiring manager interview, small take-home coding project, and team code review/interview

-   [CARTO](http://www.carto.com/careers/) | Madrid, Spain | Phone screen, take-home project, team code review/interview, hiring manager interview

-   [Casetext](https://casetext.com/jobs) | San Francisco, CA | Submit code sample for review/discussion, contract for one full day (paid)

-   [CASHLINK](https://cashlink.de/) | Frankfurt, Germany | Skype/phone interview, take-home project

-   [Causeway](http://www.causeway.com/content/opportunity) | United Kingdom, India | Skype or Telephonic discussion on approaches and experience in regards to solve projects related work, then face to face round to write small solutions to common problems in related field.

-   [Centroida](https://centroida.co/contact.html) | Sofia, Bulgaria | Series of interviews, pair programming and take-home projects

-   [Chain.Reaction](http://chainreaction.io/) | Budapest, Hungary | Partnership-fit discussion, code-review and trial days.

-   [Chargify](https://chargify.com/jobs) | San Antonio, TX / Remote | Take-home project & pair on a problem similar to daily work

-   [Checkout 51](https://checkout51.com/jobs) | Toronto, Canada | Phone conversation (15-20 minutes) followed by on-site pair programming and discussion focused on understanding decisions made during on-site work

-   [Chesapeake Technology](http://ctic-inc.com/careers/) | Denver, CO / Santa Barbara, CA / Camarillo, CA / Dulles, VA / California, MD / Remote | Phone screen (30 minutes), take home at leisure question based on real development followed by in person review of solution and general technical questions with actual team and opportunity for you to ask questions and provide feedback ( 2-3 hours)

-   [CircleCI](https://circleci.com/) | San Francisco, CA / Remote | Take-home project and discussion, followed by on-site interview that includes pair programming on actual CircleCI bugs/feature requests.

-   [City of Boston's Analytics Team](https://boston.gov/analytics) | Boston, MA | Take-home project and in-person or phone/Skype interviews

-   [City of Philadelphia's Office of Open Data & Digital Transformation](https://beta.phila.gov/departments/office-of-open-data-and-digital-transformation/jobs) | Philadelphia, PA | Take-home project

-   [Civis Analytics](https://www.civisanalytics.com/careers) | Chicago, IL | Take-home project and discussion via Skype, followed by pair programming exercise

-   [CJ Affiliate](http://jobs.cj.com/jobs/category/engineering/) | Los Angeles, CA & Westlake Village, CA | Phone coding design exercise (no algorithms), followed by an on-site final interview that includes pair programming on a realistic object-oriented design problem

-   [Clara Lending](https://clara.com/careers) | San Francisco, CA | Phone conversation around technical background and experience, followed by take-home project, pair programming and discussion

-   [Clerkie](https://angel.co/clerkie/jobs) | San Francisco, CA | Phone conversation followed by take-home project

-   [ClickMagick](https://www.clickmagick.com/) | Austin, TX / Remote | Phone conversations and examples of Free Software/Open Source work

-   [Clippings](https://clippings.com/) | Sofia, Bulgaria | Video screening first, then send us code they've recently wrote, then technical interview. We could ask questions about the code they wrote at home.

-   [Clockwork Consulting](https://www.cwconsult.dk/) | Copenhagen, Denmark | Interviews, discussion of technical background and experiences.

-   [Cloudistics](https://www.cloudistics.com/careers) | Reston, VA | Multiple interviews, discussion of technical background and experiences.

-   [Clubhouse](https://www.clubhouse.io/hiring) | New York, NY & Remote | Phone interview, followed by onsite discussions and pair programming

-   [Cogent Labs](https://www.cogent.co.jp/) | Tokyo, Japan | On-site or video call conversation around technical background and experience, followed by take-home project that resembles a problem Cogent Labs solves for. This project will serve as the base of discussion with the developers for the second interview.

-   [Cognitect, Inc.](https://www.cognitect.com/jobs) | Remote | Phone interview followed by pair programming.

-   [Cognitran](http://www.cognitran.com/employment-opportunities) | Essex, UK / Szczecin, Poland / Detroit, MI | Skype/phone interview followed by pair programming.

-   [Collabora](https://www.collabora.com/careers.html) | Cambridge, UK / Montreal, Canada / Remote | On-site or video interview, discussion of technical experience and sometimes approach for tackling a hypothetical problem.

-   [COMPEON](https://www.compeon.de/karriere) | Duesseldorf, Germany | Phone interview, followed by onsite discussions and pair programming with our developers

-   [Concordia Publishing House](http://about.cph.org/careers.html) | St Louis, MO | Take-home project followed by discussion of it on-site with future teammates.

-   [Contactlab](http://contactlab.com/en/careers) | Milan, Italy | Recruiter interview, tech interview (technical background and experiences), both on-site.

-   [Contentful](https://www.contentful.com/careers) | Berlin, Germany & SF, USA | Multiple interviews, discussion of technical background & live coding challenge (you can use the internet).

-   [ContentSquare](https://www.contentsquare.com/careers) | Paris, France | Real-world challenges with open discussions.

-   [Cookpad](https://cookpad.com/us) | Tokyo, Japan; Bristol, UK | Interviews, discussion of technical background and experiences, remotely pair with devs.

-   [Coorp Academy](https://www.coorpacademy.com/) | Paris, France | Technical interview as an open discussion

-   [CoverHound, Inc.](https://www.coverhound.com/) | San Francisco, CA | Open technical discussion, short on-site coding challenge.

-   [Credit Kudos](https://creditkudos.com/jobs) | London, UK | Take-home project and pair programming via Skype or on-site.

-   [CrossBrowserTesting](https://crossbrowsertesting.com/) | Memphis, TN | Take home project that resembles a problem support engineers deal with on a daily basis. On-Site interviews in a comfortable environement with a focus on hiring talented people vs exact skill-sets.

-   [Crowdstrike](https://jobs.jobvite.com/careers/crowdstrike/jobs) | Remote | Multiple interviews onsite or remote as appropriate followed by small take-home project.

-   [Crownstone](https://crownstone.rocks/jobs) | Rotterdam, Netherlands | Technical interaction using previously created Github projects, followed by in-person interview with a focus on someone's professional ambition in the short and long term.

-   [cube19](https://www.cube19.com/work-with-us/) | London, UK | Take-home project, then an on-site discussion about the code and previous experience.

-   [Cultivate](https://cultivatehq.com/) | Edinburgh, UK | 30 minute pair-programming screening interview on a simple exercise (remote or in-person). Half day pair programming, with 3 or 4 different team members plus informal chat, typically on-site.

-   [Culture Foundry](https://www.culturefoundry.com/) | Austin, TX | Paid take-home project

-   [CurrencyTransfer](https://www.currencytransfer.com/) | London, UK & Remote | Take-home project

## D - F

-   [Dark Sky](https://darksky.net/jobs) | Cambridge, MA | Phone interviews and a very short, real paid project

-   [Data Theorem](http://www.datatheorem.com/) | Palo Alto, CA; Paris, Fr; Bangladesh, India | Phone interview, then a take home project and finally in-person interview.

-   [Datalogue](https://datalogue.github.io/recruiting) | Montreal, Canada | We Ask candidates to contribute meaningfully to an Open source project that reflects the stack they will be working with and send us a link to the PR.

-   [DataMade](https://datamade.us/) | Chicago, IL | After submitting an application, selected applicants are moved on to a round of interviews and will be asked to submit a piece of code for review. If you don't have any code you can share, DataMade will provide a short exercise for you to complete. An in-person (or remote) interview will be scheduled to go over your background, what draws you to DataMade, and your code sample.

-   [Datascope](https://datascope.co/careers) | Chicago, IL | Take home exploratory data project with public data, discussion about the project via video chat, and in-person office visit.

-   [Datlinq](http://www.datlinq.com/en/vacancies) | Rotterdam, Netherlands | Take-home project based on actual work on data done by the team and in-person or Skype interviews

-   [DealTap](https://dealtap.ca/) | Toronto, Canada | Technical Interview, Solution Design, Take Home Assignment, then Culture fit interview with the team, and optional pair programming.

-   [Def Method](https://www.defmethod.com/) | NYC, NY | Take home test, pair programming with dev on test and client work, receive offer same day as pairing interview

-   [Deliveroo](https://deliveroo.co.uk/careers) | London, UK & Remote | Short take-home project and pair programming

-   [Dentolo](https://angel.co/dentolo) | Berlin, Germany | Phone interview with the HR department, take-home project and technical interview to discuss your skill set + general questions

-   [Deskbookers](https://www.deskbookers.com/en-gb/jobs) | Amsterdam, Netherlands | Phone screen, take-home project, on-site interview

-   [DeSmart](https://www.desmart.com/) | Gdynia, Poland | Technical interview, take-home project and talk about your experience

-   [Despark](https://despark.com/) | Sofia, Bulgaria & Remote | Culture add interview, sample code review and paid pair programming with team member or take-home project.

-   [Detroit Labs](https://www.detroitlabs.com/careers) | Detroit, MI | Our technical interview starts with a take-home assignment that we will look at during the interview. You'll walk us though your thought process, add functionality if applicable to the interview, and talk about your experience. We believe that showing us your work in a practical setting is more telling of your abilities and what you will bring to the table, than writing code on a whiteboard.

-   [DevMynd](https://www.devmynd.com/) | Chicago, IL; San Francisco, CA | Take-home project, take-home project phone review, a few hour-long pairing sessions on real projects.

-   [DG-i](https://www.dg-i.net/) | Cologne, Germany | Take-home project and/or discussion on-site about past experiences

-   [DICE](http://www.dice.se/) | Stockholm, Sweden | Take-home project and code review at the on-site

-   [Digitally Imported](http://www.di.fm/jobs) | Denver, Colorado & Remote | Video meetings on past experience and high level tech questions, take-home project

-   [Dollar Shave Club](https://www.dollarshaveclub.com/) | Venice, California | Phone interview, take-home projects, on-site interview

-   [door2door](http://door2door.io/) | Berlin, Germany | Take home challenge + on-site interview + trial day

-   [DoorDash 🏃💨](https://doordash.com/careers) | San Francisco, CA | Take home project + an on-site interview building off the project!

-   [Draft Fantasy](https://docs.google.com/document/d/1fC_-liTPpYQOoE_5iKj0O3AwSdPggQGnOsjUKahfbkQ/edit?usp=sharing) | Tel Aviv, Israel | Talk about past experience and what the developer has actually built as well as pair programming or a programming exercise.

-   [Drawbotics](https://www.drawbotics.com/en/join-us) | Brussels, Belgium | Take-home project, bootcamp on-site

-   [drchrono](https://www.drchrono.com/careers) | Mountain View, CA | Hackerrank test (but not CS trivia, it's real product problems) & on-site/take-home project w/ presentation

-   [Drivy](https://www.drivy.com/) | Paris, France | Phone screening followed by a take-home assignment, "Resume" interview, technical interview, product interview, interview with another team, finalizing the hire

-   [DroneDeploy](https://www.dronedeploy.com/careers.html) | San Francisco, CA | Pair program on a problem similar to daily work

-   [DroneSeed](https://www.droneseed.co/jobs/) | Seattle, WA | Take home assignment of a real problem we've worked on, group code review in subsequent interview.

-   [dubizzle](http://blog.dubizzle.com/uae/job-vacancies) | Dubai, UAE | Take home assignment, general technical questions, pair programming with engineers or tech leads

-   [E-accent](https://www.e-accent.com/) | Hilversum, Netherlands; Remote | Skype conversation, take-home assignment

-   [Easy Taxi](http://easytaxi.com.br/) | São Paulo, Brazil | Take-home project, interview to evaluate the candidate's previous experience.

-   [Eaze](https://eaze.com/careers) | San Francisco, CA | Take home project, on-site interview building off of the project

-   [eBay Kleinanzeigen](https://careers.ebayinc.com/join-our-team/start-your-search/find-jobs-by-location/detail/germany) | Berlin, Germany | 45 mins technical phone interview, take-home project/review, on-site interview including pair programming with team lead and agile interview with product manager.

-   [Echobind](https://echobind.com/careers) | Boston, MA; Remote | Meet the entire team, share examples of previous work and pair with one team member

-   [Edenspiekermann](https://jobs.edenspiekermann.com/) | Amsterdam, Netherlands / Berlin, Germany / Los Angeles, CA / San Francisco, CA / Singapore, Singapore | On-site chat about skills and past experiences, review some code samples or a take-home assignment

-   [EF Education First](https://careers.ef.com/) | London, UK; Boston, MA | Short phone interview, take-home project, discussion of project and real world engineering problems, meet the team.

-   [Eidu](http://eidu.com/) | Berlin, Germany | Take-home project, discussion of results with team, and test days with pair programming

-   [El Passion](http://www.elpassion.com/) | Warsaw, Poland | Take-home project, interview to 1) discuss delivered solution and 2) previous projects

-   [Electric Pulp](https://www.electricpulp.com/) | Sioux Falls, SD, USA | Phone interviews with leadership team and technical team leads. We are a tight knit team, so emphasis on a great personal fit is as important as technical prowess.

-   [Elements Interactive](https://www.elements.nl/careers) | Almere, The Netherlands & Barcelona, Spain | Take-home project & discussion via Skype or on-site

-   [Ellucian](https://www.ellucian.com/About-Us/Careers/) | Reston, VA, USA | Discussion of real world problems (from resume, if possible)

-   [elmah.io](https://elmah.io/) | Aarhus, Denmark / Remote | Discussion about code and looking at hobby projects (if any)

-   [Elvie](https://www.elvie.com/) | London, England | Discussing real code, pairing and a paid day to see how you work with the team. No coding for free or time-restricted take-home projects, code challenges or abstract algorithm tests

-   [eMarketer](https://goo.gl/N7SMKl) | New York, NY | Short phone interview, then come in and meet the team, check out our space, and have a discussion with team members about real-world problems

-   [Emarsys](https://www.emarsys.com/) | Budapest, Hungary | Take-home project (small, 1-2 days to solve), then discussion on-site

-   [Endava](http://www.endava.com/en/Careers) | Belgrade, Serbia; Bucharest, Romania; Chisinau, Moldova; Cluj-Napoca, Romania; Iasi, Romania; Pitesti, Romania; Skopje, Macedonia; Sofia, Bulgaria; Frankfurt, Germany; Glasgow, Scotland; Hilversum, Netherlands; London, UK; Oxford, UK; Bogota, Colombia; Atlanta, GA; New Jersey, NJ; New York, NY | On-site discussion about previous experience and technical questions about the target technologies.

-   [Engel & Völkers Technology](https://www.engelvoelkers.com/en/tech/) | Hamburg, Germany | Remote technical interview with an Engineering Manager, followed by a practical coding challenge implemented in 5 hours, ending with a technical discussion with the team on the produced code either remotely or on-site based on geographical practicality.

-   [Enhancv](https://enhancv.com/about.html) | Sofia, Bulgaria | Talk is cheap, show us your code: github profile or other project examples. Explain them in person / remotely. Discuss habits and interests to see if we have a culture fit.

-   [Enigma](https://www.enigma.com/) | New York, NY | 2-part takehome project, followed by a pair programming exercise

-   [Enki](https://enki.com/) | London, UK | Skype/phone interview followed by takehome project

-   [Ento.com](https://ento.com/blog/ento-interview-process-101) | Melbourne, Australia | On-site interview to talk about your experiences and what you're looking for in your next role, followed by a take-home practical test relevant to the work you'll be undertaking at Ento.

-   [Equal Experts](https://www.equalexperts.com/) | London, UK; Manchester, UK; New York, NY; Pune, India; Lisbon, Portugal; Calgary, Canada | Fizzbuzz test done at home followed by Pair Programming session at office and finally face to face technical and attitude interview.

-   [Ericsson](https://www.ericsson.com/) | Dublin, Ireland | Skype/phone interview followed by Face 2 Face interview, discussions and architecture questions followed by final small project on a problem similar to daily work.

-   [eShares, Inc](https://esharesinc.com/jobs) | San Francisco, CA; Palo Alto, CA; Seattle, WA; Rio de Janeiro, Brazil; London, UK; New York, NY | Phone call, practical technical screen, on site to meet the team & explore the company

-   [Etix Everywhere](https://www.etixeverywhere.com/en/job-offers) | Luxembourg City, Luxembourg

-   [EURA NOVA](https://euranova.eu/) | Mont-Saint-Guibert, Belgium; Marseille, France; Tunis, Tunisia | attitude interview, unpaid take-home project, technical discussion with 1 or 2 technical employees (remote or face 2 face), face 2 face discussion with HR, partner, and technical staff to have a foretaste of the collaboration

-   [Euro Payment Group](http://www.europaymentgroup.com/) | Frankfurt, Germany | Take-home project followed by face to face interview

-   [Exoscale](https://exoscale.ch/) | Bern, Switzerland | Take-home project. Discussion and presentation. Then entire team meet.

-   [F(x)](https://fdex.com.br/) | São Paulo, Brazil | Skype interview, Take-home project and onsite interview to evaluate the candidate

-   [Falcon.io](https://www.falcon.io/jobs/) | Copenhagen, Denmark | Initial call/Skype culture interview. Take-home tech assignment (game) and code review. On-site Interview about your experience and meeting the team.

-   [FATMAP](https://www.fatmap.com/) | London, UK; Berlin, Germany; Vilnius, Lithuania | Skype discussion, Take-home project, Face to face

-   [Fauna](https://fauna.com/) | San Francisco, CA / Remote | Take home project, then follow up with interviews on-site or remote. Interviews are both technical and non-technical. Technical interviews comprehend the scope of the home project.

-   [Feather](https://feather-cfm.com/) | Remote | Take-home challenge, portfolio discussion & team meeting

-   [Findy](https://blog.findy.us/findy-saiyo) | Tokyo, Japan | Tech interview + On-site discussion

-   [FINE](https://www.wearefine.com/careers) | Portland, OR | Small take-home challenge + follow-up discussion

-   [Firemind](https://www.firemind.io/) | Maidstone, UK; London, UK; Remote | Small pre-interview challenge on github + discussion face to face in person or via video

-   [Fitbot](https://thefitbot.com/careers.html) | Boulder, CO | Pairing & writing code with the founders for a few hours

-   [Flatfox](https://flatfox.ch/) | Zurich, Switzerland | Informal conversation to check mutual fit, small (4h) take-home assignment, discussion in team

-   [Fluidly](https://fluidly.com/) | London, UK | Casual 30min phone call. ~1hr take home tech exercise (not pass or fail). 1 stage onsite interview - discussion about experience, 1 hour pair programming on the real code base, then your turn to interview us!

-   [Food52](https://food52.com/jobs) | New York, NY; Remote | Take-home project, discussion on-site or remote, interviews with both technical and non-technical staff

-   [Fooji](https://fooji.com/) | Lexington, KY; Remote | Take-home project

-   [Formidable Labs](https://www.formidable.com/careers) | Seattle, WA; London, UK; Remote | Take-home project, remote pair programming, discussion on-site or remote

-   [Fortumo](https://fortumo.com/careers) | Tallinn, Estonia; Tartu, Estonia | After a 30-min call you get a simplified version of a task that has recently been a challenge for the engineering team

-   [Founders](https://founders.as/joinus) | Copenhagen, Denmark | Take Home project + Interviews

-   [Foundry Interactive](http://www.foundryinteractive.com/contact) | Seattle, WA | On-site or remote discussion, paid trial project with pairing and code reviews

-   [fournova](https://www.fournova.com/jobs) | Remote | Take-home project, discussion via video call

-   [FreeAgent](https://www.freeagent.com/company/careers) | Edinburgh, UK | Take-home project, pair programming, discussion and interviews

-   [Freeletics](https://www.freeletics.com/en/corporate/jobs) | Munich, Germany | Small real-world challenge, multiple interviews on-site/remote and social gathering with team.

-   [Freetrade](https://www.freetrade.io/careers) | London, England | Initial hangout with fizz buzz style question followed by an on-site real world coding question and systems design conversation.

-   [FRIDAY](https://friday-jobs.personio.de/) | Berlin, Germany | Take-home real-world challenge, interview on-site or remote

-   [Frontside](https://frontside.io/careers) | Austin, Texas | Phone interview with remote pairing session. Followed by in person pairing (paid for the day) and lunch with the team.

-   [Funda](https://www.funda.nl/vacatures) | Amsterdam, The Netherlands | Take Home test + Discussion On-Site/Remote

-   [FundApps](https://www.fundapps.co/about-us/join-our-team) | London, UK | Coffee with an Engineer; take-home kata; code review + on-site pair programming exercise.

## G - I

-   [Gamevy](https://www.gamevycareers.com/) | London, UK; Bilbao, ES; Remote | Informal culture discussions, pair programming with our engineers

-   [Garner](https://www.garnercorp.com/) | Toronto, Canada | step 1: online chat with hiring manager, step 2: at home assignment solving real-life problem, step 3: on-site pair programming with engineers, step 4: offer

-   [GatherContent](https://gathercontent.com/careers/designer) | Remote | Culture-first interviews, pair programming and remote, informal technical discussions

-   [GeneralUI](https://generalui.com/) | Seattle, WA | A short phone screen with questions regarding general knowledge related to the open position, then a half day pair programming interview.

-   [Ginetta](http://jobs.ginetta.net/) | Zurich, Switzerland; Braga, Portugal | Culture-first interviews, take home assignment that resembles a real-world problem we often solve, then discussion about the assignment in-person with pair-programming improvement sessions with our developers.

-   [GitHub](https://github.com/about/careers) | Remote; San Francisco, CA; Boulder, CO| Take-home exercise, code review and technical discussions.

-   [GitPrime](https://www.gitprime.com/) | Denver, CO; Remote | small short term real-world project, paid project on production code

-   [Glints](https://glints.com/sg/inside/careers/) | Singapore, Singapore; Jakarta, Indonesia | Culture fit interview, take home assignment that resembles a real-world problem, walkthrough about the assignment

-   [GoCardless](https://gocardless.com/about/jobs) | London, UK | Project to work at home, general technical questions, pair programming with engineers

-   [GoDaddy](https://www.godaddy.com/careers/overview) | Sunnyvale, CA | Pair programming with senior engineers

-   [GoJek](https://www.gojek.io/) | Bangalore, India; Jakarta, Indonesia; Singapore, SG; Bangkok, Thailand | Take-home exercise, Pair programming with senior engineer, Techinal problem solving and discussion, Cultural Fit

-   [Gower Street Analytics](http://gower.st/) | Remote; London, UK | Initial telephone chat, then either a) work with us, fully paid, for a day on real code with the team; or b) pair-programming on a code kata with the team members for four pomodoros. Your choice.

-   [Graffino](https://www.graffino.com/) | Sibiu, Romania | Take-home project, discussion on-site

-   [Grafton Studio](https://graftonstudio.com/) | Boston, MA | Take-home project, discussion on-site

-   [Gramercy Tech](http://www.gramercytech.com/) | New York, NY | Pair programming & discussion on-site

-   [grandcentrix](https://www.grandcentrix.net/jobs) | Cologne, Germany | Take-home project, discussion on-site

-   [Grape](https://www.chatgrape.com/jobs/) | Vienna, Austria / Remote | Github or code samples -> Pair programming -> Skype/phone interview

-   [Graphcool](https://www.graph.cool/) | Berlin, Germany | On-site pair programming of a small, isolated real world task

-   [Graphicacy](http://www.graphicacy.com/) | Washington, DC | Phone interview; in-person or virtual interview depending on location and availability; two brief technical assignments focused on flexibility, creativity, and general competency

-   [Graphistry](https://www.graphistry.com/careers) | Oakland, CA; San Francisco, CA; Remote | Engineering, culture, and product discussions, and for junior developers, choice of take home or code review.

-   [Grok Interactive](https://www.grok-interactive.com/) | San Antonio, TX | Take-home project with code review and a follow-up in-person interview.

-   [Gruntwork](http://www.gruntwork.io/) | Remote | Paid, take-home project with pair coding

-   [GTM Sportswear](https://gtmsportswear.com/careers) | Manhattan, KS / Remote | Remote pairing session, then a take-home test.

-   [Happy Team](https://happyteam.io/) | Warsaw, Poland; Remote | General technical questions, takehome paid exercise with feedback/discussion during implementation

-   [Happypie](http://www.happypie.com/) | Uppsala, Sweden | Takehome excercise with code review after, in-person interview

-   [Hash](https://www.hash.com.br/index.html) | Sao Paulo, Brazil | Take-home project and/or discussion (on-site or remote)

-   [Hashrocket](https://hashrocket.com/) | Chicago, IL/Jacksonville Beach, FL | Remote pairing session, paid week pair programming with everyone on the team

-   [Headspring](https://headspring.com/about/careers) | Austin, TX; Houston, TX; Monterrey, Mexico | Take-home situational questionnaire and code exercise, with in-person follow up to discuss and pair for changes

-   [Healthify](https://healthify.us/) | Remote & New York City, NY | Take-home project, discussion via Zoom, pair programming with us on our app for a day.

-   [Heetch](https://www.heetch.com/) | Paris, France | Values-fit interview (via zoom.us), Take-home project with review, Team Discussions (via zoom.us), on-site day

-   [HE:labs](https://helabs.com/) | Rio de Janeiro, Brazil & Remote | Take-home project and discussion via Skype.

-   [HelloFresh](https://www.hellofresh.com/jobs) | Berlin, Germany | Take-home project, discussion via Skype or on-site

-   [Heptio](https://www.heptio.com/jobs) | Seattle, WA; Remote | Take-home project, discussion on-site

-   [Hill Holliday](http://www.hhcc.com/careers) | Boston, MA | Take-home project on GitHub, in-person interview / culture fit interview

-   [Hireology](http://www.hireology.com/careers) | Chicago, IL; Remote | Walk through personal/work projects and discuss experience

-   [Hiventive](https://www.hiventive.com/) | Pessac, France | Phone interview, home coding challenge, on-site interview with general programming questions, discussion of proposed solutions and personal experience.

-   [HolidayPirates](https://holidaypirates.group/en/jobs) | Berlin, Germany | Take-home project, discussion via Skype or on-site

-   [HoloBuilder](https://www.holobuilder.com/) | Aachen, Germany | Take-home project, discussion via Skype or on-site

-   [Home Chef](https://www.homechef.com/careers) | Chicago, IL; Remote | Get-to-know-you meeting with the team, followed by a half-day collaborative coding session

-   [HomeLight](https://www.homelight.com/engineering) | San Francisco, CA; Scottsdale, AZ; Seattle, WA | Phone screen, take home that is close to production code, onsite with pair programming

-   [HoxHunt](https://jobs.hoxhunt.com/) | Helsinki, Finland | Take-home project, pair programming on-site

-   [Human API](http://humanapi.co/company/careers) | Redwood City, CA | Technical phone interview, then on-site pair programming and design discussion

-   [I|O](https://io.co.za/opportunities) | Cape Town, South Africa

-   [Icalia Labs](http://icalialabs.com/) | Monterrey, Mexico | Pair programming, cultural fit session

-   [iConstituent](http://iconstituent.com/careers/) | Washington, DC | Take-home project and code review in-person

-   [Ideamotive](https://ideamotive.co/) | Warsaw, Poland & Remote | Take-home project, technical interview with developer

-   [IDEO](https://www.ideo.com/jobs) | San Francisco, CA; New York, NY; Chicago, IL; Cambridge, MA | Take home project that resembles a problem IDEO solves for, then pairing session in person or over video chat.

-   [ImmobilienScout24](https://boards.greenhouse.io/scout24) | Berlin, Germany | Take-home project, discussion on-site

-   [Impraise](http://jobs.impraise.com/) | Amsterdam, The Netherlands | Take home test, real world pair programming

-   [Incloud](https://jobs.incloud.de/) | Darmstadt, Germany | Technical interview with developers, followed by a full day on site with a practical project

-   [Indellient](http://www.indellient.com/careers) | Oakville, Canada | Series of interviews both technical and non-technical

-   [InfluxData](https://www.influxdata.com/careers) | San Francisco, CA & Remote | Technical and non-technical interviews, pair programming, with prospective manager and multiple prospective teammates

-   [InfoSum](https://www.infosum.com/) | Basingstoke, UK | On-site unsupervised exercise & discussion.

-   [inKind Capital](https://inkindcapital.com/) | Boulder, CO | Discussing real-world problems, pair programming, dinner & drinks with the team

-   [Inmar](https://www.inmar.com/careers) | Winston-Salem, NC; Austin, TX & Remote | Take-home project and conversation-style interviews

-   [Innoplexus](https://www.innoplexus.com/careers/) | Pune, India; Frankfurt, Germany | Take-home projects and On-site pair programming assignment.

-   [Instacart](https://careers.instacart.com/) | San Francisco, CA | Take-home real world project, pair programming on-site

-   [InstantPost](https://internshala.com/internships/internship-at-InstantPost) | Bangaluru, India | Remote assignment followed by Technical and Team round interview

-   [Integral.](https://www.integral.io/) | Detroit, MI | Initial remote technical screen featuring test-driven development & pair programming, then on-site full day interview that involves pair programming on production code using test-driven development.

-   [Intelipost](https://www.intelipost.com.br/) | São Paulo, BR | Take-home project, on-site code review and presentation (skype available if needed), discussion involving real world problems and interviews with different teams

-   [Intercom](https://www.intercom.com/careers) | San Francisco, CA; Chicago, IL; Dublin, Ireland | Real-world technical design and problem discussion, pair programming on-site

-   [Interset](https://interset.com/careers) | Ottawa, Canada | Discussion of technical background and past experience. Relevant take-home project for junior developers

-   [Ithaka](https://www.ithaka.travel/) | Mumbai, India | Phone interview followed by a small development task. Finally a phone interview with CEO.

-   [iTrellis](http://itrellis.com/) | Seattle, WA | Phone screen, then a take-home project, then pairing (remote or on-site) with 3 developers on the take-home project.

-   [iZettle](https://jobs.izettle.com/jobs) | Stockholm, Sweden | Remote pair programming exercise, propose an architecture for an application and discuss about it in an informal format.

## J - L

-   [Jamasoftware](http://www.jamasoftware.com/) | Portland, OR | Initial phone screen with hiring manager. In person pairing on project similar to day-to-day work with a separate cultural interview

-   [Jamit Labs](https://jamitlabs.com/jobs) | Karlsruhe, Germany | Phone interview or on-site interview & take-home code challenge or on-site programming session

-   [Jiminny](https://www.jiminny.com/) | Sofia, Bulgaria | Phone screen. Take-home exercise. Follow-up discussion.

-   [Jitbit](https://www.jitbit.com/) | Remote; London, UK; Tel-Aviv, Israel | Take-home real-world task

-   [Jobtome](https://weare.jobtome.com/careers) | Stabio, Switzerland | Phone screen introduction with hiring manager. In site (or screen call) with Engineer Manager for a talk on skills and cultural fit.

-   [Journal Tech](https://journaltech.com/jobs) | Los Angeles, CA | Mini take-home project, phone interview, discussion on-site

-   [Journalism++](http://www.jplusplus.org/) | Berlin, Germany | Apply through a [relevant online challenge](http://internship.jplusplus.org/) to show your technical skills and your capacity to investigate

-   [JustWatch](https://www.justwatch.com/us/talent) | Berlin, Germany | Take-Home project, discussion on-site

-   [K Health](https://www.khealth.ai/) | Tel Aviv, Israel | Phone screening to discuss technical background and past experience. Take-home assignment followed by on-site code review and interview. Cultural fit assessment

-   [Kahoot!](https://www.getkahoot.com/jobs) | London, UK / Oslo, Norway | Phone screening to discuss technical background and past experience. Take-home assignment followed by on-site code review and interview. Cultural fit assessment

-   [Kata.ai](https://kata.ai/) | Malang, Indonesia / Jakarta, Indonesia | Take-home assignment, then invited to discuss the assignment and interview.

-   [Kayako](https://www.kayako.com/) | London, UK / Gurgaon, India | Take-home assignment, series of experience based interviews, cultural fit assessment

-   [Kentik](https://www.kentik.com/careers) | San Francisco, CA | Phone screening to discuss technical background and past experience. Take-home assignment followed by on-site code review and interview. Cultural fit assessment

-   [Keymetrics](https://keymetrics.io/) | Paris, France | Phone Interview, Take-home project based on our [API](https://github.com/keymetrics/keymetrics-api), IRL meeting with the whole team

-   [Kindred Group, Native Apps Team](https://careers.kindredplc.com/) | Stockholm SE, London UK | On-site/Skype programming task, Interview

-   [Kinnek](https://www.kinnek.com/jointeam) | New York, NY | Phone screen, on-site pairing session, take-home project

-   [Kiwi.com](https://code.kiwi.com/) | Brno, Czech Republic | Phone Interview, Take-home projects, On-site code review & interview

-   [KNPLabs](https://knplabs.com/) | Nantes, France | First step: screening call directly with the CEO, to discuss company vision, assess cultural fit and experience. Second step: call or IRL interview with a developer and a project facilitator , technical discussions with focus on soft skills. The goal of the interview is for the 2 KNPeers to be able to answer: “Do I want to work with this person ?” If both say yes, the person is hired. If even at least one says no, the person is not hired.

-   [Koddi Inc.](http://www.koddi.com/open-positions) | Fort Worth, TX | Phone Interview(s), take-home project, on-site interview

-   [Kong](https://www.konghq.com/careers) | San Francisco, CA | Phone interview. Pairing and technical interviews. Take home assigment.

-   [Kongregate](http://www.kongregate.com/jobs) | Portland, OR | Phone screening. Take home project. On-site pairing and conversational technical interviews.

-   [Korbit](https://www.korbit.co.kr/about/jobs) | Seoul, South Korea | Take home assignment followed by on-site code review and interview

-   [Lab.Coop](http://lab.coop/) | Budapest, Hungary | Partnership-fit discussion, code-review and trial days.

-   [Landing.jobs](https://landing.jobs/at/landing-jobs) | Lisbon, Portugal | Interviews (in-person or remote), Take home coding project

-   [Lanetix](http://engineering.lanetix.com/) | San Francisco, CA | [Our Hiring Process](https://engineering.lanetix.com/2015-10-20/hiring-process)

-   [LateRooms](http://careers.laterooms.com/) | Manchester, UK | Telephone interview followed by coding problem at home. Suitable submissions proceed to an onsite interview.

-   [Launch Academy](https://launchacademy.com/careers) | Boston, Philadelphia | Nontechnical phone screen, pair programming with team member, and potentially a "guest lecture" for our students

-   [LaunchDarkly](https://launchdarkly.com/careers) | Oakland, CA | Informational phone screen with Eng leadership, take home project, onsite interviews

-   [Learningbank](https://learningbank.dk/) | Copenhagen, DK | Take home assignment, followed by on-site code review.

-   [Legalstart.fr](https://www.legalstart.fr/) | Paris, France | Telephone interview followed by take-home challenges. Suitable applicants are asked to do further on-pair interviews on site.

-   [Leverton](https://www.leverton.ai/) | Berlin, Germany | Initial chat with the HR continued with 1-2 rounds chat with the team; followed by a technical test and finally a chat with the CTO/MD. [Jobs page](http://leverton-jobs.personio.de/)

-   [Liberty Mutual](https://www.libertymutualgroup.com/careers) | Seattle, WA; Boston, MA; Indianapolis, IN | Initial interview, discussion on-site, interview with peers

-   [Librato](https://www.librato.com/jobs) | San Francisco, CA; Boston, MA; Austin, TX; Vancouver, Canada; Krakow, Poland | Take home coding project, conversational technical interviews on-site

-   [Lightning Jar](http://lightningjar.agency/) | San Antonio, Tx | Remote pairing session, Initial interview,discussion on-site

-   [Lightricks](http://www.lightricks.com/) | Jerusalem, Israel | Initial interview, Take home project, discussion on-site

-   [LinkResearchTools](http://jobs.linkresearchtools.com/job-offers) | Vienna, Austria | Skype interview, mini take-home exercise, discussion on-site / personal interview

-   [Listium](https://listium.com/jobs) | Melbourne, Australia | Design and code proof of concept features with the team

-   [Litmus](https://litmus.com/careers#openings) | Remote | General technical questions, take-home code challenge, discussion, on-site programming session, meet & greet with the team

-   [LittleThings](https://www.littlethings.com/careers.html) | New York, NY | Take home code challenge, Discussion

-   [LoanZen](https://loanzen.in/team.html#Career) | Bengaluru, India | Initial phone interview about experience, a solve-at-home project based on the kind of work we do at our company, on-site interview discussing the submitted solution and a general discussion with the whole team

-   [Lob](https://lob.com/careers) | San Francisco, CA | Initial phone screen followed by an on-site interview. Technical problems discussed during the interview are all simplified versions of problems we've had to solve in production. Our entire interview process and what we're looking for is described in our blog post [How We Interview Engineers](https://lob.com/blog/how-we-interview-engineers).

-   [Locastic](https://www.locastic.com/posao) | Split, Croatia | Take-home code challenge, tehnical discussion & on-site programming session, meet & greet with the team

-   [Locaweb](https://www.locaweb.com.br/carreira) | São Paulo, Brazil | Skype interview, take-home project and discussion on-site

-   [LOGIBALL GmbH](https://logiball.de/en/jobs/) | Berlin, Hannover and Herne in Germany | Interviews and discussion

-   [Logic Soft](https://logicsoft.co.in/) | Chennai, India | Phone discussion, F2F pair programming exercise + discussion

-   [LonRes](https://www.lonres.com/public/working-us) | London, United Kingdom | Quick introduction call with tech (Skype), coding task for ≈1 hour, face-to-face interview (or via Skype) and meeting with team members.

-   [LookBookHQ](http://www.lookbookhq.com/about/careers) | Toronto, Canada | On-site discussion, pair programming exercise

-   [Loom](https://www.useloom.com/careers) | San Francisco, CA | Google Hangouts resume dive on past experience, take-home project OR architectural phone screen, on-site interviews (2 technical architecture related to work, 1 or 2 non-technical)

-   [Lydia](https://lydia-app.com/en/company/jobs) | Paris, FR | Mini take-home project, phone interview, discussion on-site

-   [Lyft](https://lyft.com/jobs) | San Francisco, CA | Pair programming on-site with your own personal laptop

-   [Lyoness Austria GmbH](http://www.lyoness-corporate.com/de-AT/Karriere/Jobangebote) | Graz, Austria | Take-Home project, discussion on-site

## M - O

-   [Made Tech](https://www.madetech.com/careers) | London, UK | [Our hiring process](https://github.com/madetech/handbook/tree/master/guides/hiring#20-minute-phone-conversation)

-   [Magnetis](https://magnetis.workable.com/) | São Paulo, Brazil & Remote | Phone interview + take home assignment, followed by pair programming and informal meeting with the team.

-   [Major League Soccer](https://careers-mlssoccer.icims.com/jobs/search?ss=1&searchCategory=20285) | New York, NY | Phone interview + short take home project, which is daily work focused. In person interview could involve discussing past projects or pair programming.

-   [MakeMusic](http://www.makemusic.com/careers/) | Boulder, CO; Denver, CO | Phone screen, take home project, remote and on-site interviews for technical and cultural fit

-   [MakeTime](https://maketime.workable.com/) | Lexington, KY | Practical exercise and/or a pairing session on site

-   [Mango Solutions](http://www.mango-solutions.com/wp/about-mango/team) | London (UK), Chippenham (UK) | Initial phone interview, followed by on-site interview with take-home assignment

-   [Mapbox](https://www.mapbox.com/jobs) | San Francisco, CA; Washington, DC; Ayacucho, Peru; Bangalore, India; Berlin, Germany; Remote | Conversational interviews, paid onsite project with team.

-   [Mavenlink](https://www.mavenlink.com/careers) | San Francisco, CA; Irvine, CA; Salt Lake City, UT | On-site pairing with multiple engineers. Pairing exercises and pairing on company code.

-   [Maxwell Health](https://www.maxwellhealth.com/careers) | Boston, MA | Take-home exercise or pairing session with team. Then conversational meetings with members of the team.

-   [Me & Company](https://me-company.de/jobs/) | Düsseldorf, Germany | You join us for one or two paid trial days to work on an assignment and to meet the team.

-   [Media Pop](https://mediapop.co/) | Singapore, Singapore | Take-home or unsupervised (onsite) real-world assignment

-   [Meetrics](https://www.meetrics.com/) | Berlin, Germany | Initial interview, take-home code challenge and review

-   [Meltwater](http://underthehood.meltwater.com/jobs) | Manchester, NH | Small take home exercise that will be presented to the team during a QA style interview

-   [Mention](https://mention.workable.com/) | Paris, FR | Take-home small exercise followed up by on site meetings with your future coworkers

-   [Mercatus](https://www.mercatus.com/company/careers) | Toronto, Canada | Practical on-site project similar to daily work

-   [mfind](https://www.mfind.pl/dolacz-do-nas/) | Warsaw, PL | Phone call about technical experience, Take-home project or technical test(depends on experience), Onsite interview with technical lead.

-   [miDrive](https://midrive.com/careers) | London, UK | Phone screen, Take-home project / technical test, Onsite interview with senior and peer.

-   [milch & zucker](https://www.milchundzucker.de/) | Gießen, Germany | Interview with direct feedback, applicants providing working sample, code review (product code or personal code of applications)

-   [Mimir](https://mimirhq.com/jobs/) | Indianapolis, Indiana | Take home interview, phone screen, in person interview where you decide how you want to be interviewed (questions, pair programming, etc.)

-   [Minute Media](http://www.minutemedia.com/careers/) | Tel-Aviv, Israel | Phone screening with engineer. On-site real-world challenge questions with two engineers. Sometimes a take-home assignment or existing code sample submission.

-   [Mirumee](https://mirumee.com/jobs) | Wroclaw, Poland; Remote | Pair programming and code review using one of the issues (or Pull Requests) in our open-source Saleor project, general discussion about programming, technology and candidate's experience

-   [Mixmax](https://mixmax.com/careers) | San Francisco, CA | Takehome assignment purely based on their platform, followed by phone interview

-   [MobileCashout](https://www.mobilecashout.com/) | Barcelona, Spain; Valencia, Spain | Quick introduction video call with a tech (less than 10-15 minutes). On-site open source contribution to a project of candidates choosing, paired with a tech from the team. Interview and a short questionaire about software design and relevant technologies. Interview and presentation of the company with a HR rep.

-   [Mobilethinking](https://mobilethinking.ch/) | Geneva, Switzerland | 1 hour discussion about technical background and past experiences, preferably in-person

-   [Mode](https://about.modeanalytics.com/careers) | San Francisco, CA | Phone interview followed by onsite pair-architecting and discussion

-   [MokaHR](http://mokahr.com/) | Beijing, China | Take home project/challenge, then on-site programming session taken from problems we encounter at work

-   [Moneytree Front-end Web Team](https://moneytree.jp/) | Tokyo, Japan | Pair programming exercise and social gathering with team

-   [Monzo](https://monzo.com/) | London, UK & Remote | Phone interview with another engineer. Take-home assignment. Call to debrief on take-home assignment. Half-day interview (on-site or Hangouts) with three conversational sessions: (1) building on take-home test & real-world system design (verbal and collaborative); (2) digging into knowledge & understanding in 1-2 other relevant technical areas; (3) general background, teams and ways of working.

-   [Moteefe](https://www.moteefe.com/jobs) | London, UK & Remote | Interview with CTO. Take home project/challenge.

-   [Mutual Mobile](https://mutualmobile.com/careers) | Austin, TX; Hyderabad, India | Technical discussion, code test based on actual work you'll be doing, panel style discussions for cross-functional and culture-fit.

-   [Mutual of Omaha](http://www.mutualofomaha.com/careers) | Omaha, NE, USA | Panel Style Interviews analyzing problem solving, ability to adapt well to change, and interpersonal communication skills.

-   [Mutually Human Software](https://www.mutuallyhuman.com/) | MI, OH, WA | Collaborative problem analysis and design exercise, pairing exercise

-   [Nanobox](https://nanobox.io/) | Lehi, UT; Remote | A phone/video/person-to–person interview with a look at past projects (github, bitbucket, source code, etc.)

-   [Native Instruments](https://www.native-instruments.com/) | Berlin, Germany | Takehome programming assignment and personal interviews with part of the hiring team.

-   [Nearsoft Inc](https://nearsoft.com/join-us/) | Hermosillo, Mexico; Chihuahua, Mexico; Mexico City, Mexico | Takehome [logic test](https://nearsoft.com/blog/the-logic-behind-nearsofts-logic-test/), english interview to check communication skills, short technical interview about experience, long technical discussion about languages/tools/practices you will use on daily basis, pair programming session.

-   [Nedap](http://lifeatnedap.com/vacatures) | Groenlo, Netherlands / Remote | A simple conversation, human to human and a small on-site project

-   [Neoteric](https://neoteric.eu/career/) | Gdańsk, Warsaw Poland; Remote | Face2Face conversation, take home exercise & pair programming session

-   [Netflix](https://jobs.netflix.com/jobs/867042) | Los Gatos, CA | Takehome exercise, series of real-world interviews with engineers, HR, engineering managers and our director

-   [Netguru](https://www.netguru.co/career) | Warsaw, Poland; Remote | Takehome exercise & pair programming session

-   [Netlandish](https://www.netlandish.com/) | Los Angeles, CA; Remote | Takehome exercise, chat interview, video interview

-   [Netlify](https://www.netlify.com/careers) | San Francisco, CA | Paid takehome project and online/onsite discussion

-   [New Relic](https://newrelic.com/about/careers) | San Francisco, CA | Takehome exercise &/ or pair programming session depending on the team

-   [NewStore](https://www.newstore.com/careers/) | Berlin, Germany; Hannover, Germany; Erfurt, Germany; Boston, MA | Telephone technical interview, code sample submission or takeaway coding exercise, on-site pair programming, design session (1/2 day)

-   [NewVoiceMedia](https://www.newvoicemedia.com/about-newvoicemedia/careers) | Basingstoke, England; Wroclaw, Poland | Telephone interview, takeaway coding exercise, on-site pair programming, code review & technical discussion (1/2 day)

-   [Nexcess.net](https://nexcess.net/) | Southfield, MI | We mostly chat to get a feel on both ends if there's a good cultural fit. We ask questions to see what experience you have and how you think as a programmer. At some point we look at some of your code or have you work on some of ours (1 hour).

-   [Nimbl3](https://www.workhiro.com/companies/nimbl3) | Bangkok, Thailand | Takehome exercise and specific role discussion

-   [Niteoweb](http://www.niteoweb.com/careers) | Ljubljana, Slovenia | Join us for a week to see if we fit

-   [Nitro](https://www.gonitro.com/about/jobs) | Dublin, Ireland; San Francisco, CA | Phone Call, Take Home Test, Hiring Manager Phone Interview followed by an onsite discussion

-   [Noa](https://www.noa.one/) | Berlin, Germany; San Francisco, CA | 1 technical chat, 2-3 cultural chats with colleagues from different departments in the team, if these work a pair programming exercise

-   [NodeSource](http://nodesource.com/careers) | Remote | A person-to–person walk through of a past project of yours

-   [Nomoko,camera](https://www.nomoko.world/jobs) | Zurich, Switzerland | Three interrogations

-   [Nord Software](https://www.nordsoftware.com/en/jobs) | Helsinki, Finland; Tampere, Finland; Stockholm, Sweden | Take-home exercise & interview with CEO and senior developer

-   [NoRedInk](https://www.noredink.com/jobs) | San Francisco, CA | Take-home exercise & pair programming session

-   [NoviCap](https://novicap.com/en/careers.html) | Barcelona, Spain | Takehome exercise & discussion on-site

-   [Novoda](https://novoda.com/hiring) | London, UK; Liverpool, UK; Berlin, Germany; Barcelona, Spain; Remote | 2 x Pairing sessions & conversational interviews [(public repo)](https://github.com/novoda/dojos)

-   [Novus Partners](https://www.novus.com/jobs) | New York, NY | Take-home exercise & on-site exercises (choice of laptop or whiteboard)

-   [Nozbe](https://nozbe.com/jobs) | Remote | Take-home exercise & interview with the team

-   [npm, Inc](https://npmjs.com/jobs) | Oakland, CA / Remote | No technical challenges. Just interview conversations.

-   [Nubank](https://nubank.workable.com/) | São Paulo, BR | Phone conversation, take-home exercise, code walkthrough, on-site code pairing.

-   [numberly](https://www.numberly.com/) | Paris, France | Series of interviews, that go over technical background, past experiences and cultural knowledge

-   [numer.ai](https://angel.co/numerai/jobs) | San Francisco, CA

-   [Nutshell](https://www.nutshell.com/jobs) | Ann Arbor, MI, US | Email screen / take-home programming excercise ([public repo](https://github.com/nutshellcrm/join-the-team))

-   [Nyon](https://www.nyon.nl/vacatures) | Amsterdam, The Netherlands | 1. Skype (or real life) interview 2. Take home exercise (3-4 hours) 3. Meet entire team and pair programming sessions

-   [O'Reilly Media](https://oreilly.com/jobs) | Sebastopol, CA; Boston, MA; Remote | Phone conversation, take-home exercise or pair programming session, team interview, all via Google Hangout

-   [Object Partners, Inc.](https://objectpartners.com/careers/) | Minneapolis, MN; Omaha, NE | Phone interview to gauge mutual interest, followed by a slightly more in-depth technical round-table interview

-   [Objective, Inc.](https://www.objectiveinc.com/careers) | Salt Lake City, UT | Take-home programming exercise, then onsite friendly chat with team

-   [OCTO Technology](http://rejoins.octo.com/) | Paris, France | HR interview to go over your experiences and cultural knowledge. Then more or less informal discussion with two future team members about architecture design, agile practices, take-home project, pair programming...

-   [Olist](https://olist.com/) | Curitiba, Brazil | Take-home project and remote or on-site interviews

-   [Omada Health](https://www.omadahealth.com/jobs) | San Francisco, CA | Take home exercise and/or pair programming session.

-   [Onfido](https://onfido.com/jobs) | London, UK; Lisbon, Portugal | Take-home exercise and on-site interview/discussion with potential team

-   [Ontame.io](https://ontame.io/) | Copenhagen, Denmark | Take home exercise and specific role discussion

-   [Opbeat](https://opbeat.com/jobs#seniorbackendengineer) | Copenhagen, Denmark | Pairing on a real-world problem

-   [Openmind](https://www.openmindonline.it/) | Monza, Italy | On-site interviews

-   [Optoro](http://www.optoro.com/open_position_item/?oid=134960) | Washington, DC | Take home exercise. Review your code onsite.

-   [Ostmodern](http://www.ostmodern.co.uk/) | London, UK | Take-home exercise & discussion on-site

-   [Outbrain](https://www.outbrain.com/jobs) | NYC, Israel | Take-home exercise & discussion

-   [Outlandish](https://outlandish.com/) | London, UK | Take-home exercise, real-world pair programming session, friendly chat with team

-   [Outlook iOS & Android](https://github.com/outlook/jobs) | San Francisco, CA / New York, NY | Take-home project & online / onsite discussion

-   [The Nerdery](https://www.nerdery.com/careers) | Minneapolis, MN; Chicago, IL; Phoenix, AZ; Kansas City, KS | Take-home exercise

-   [The Outline](https://boards.greenhouse.io/theoutline) | New York, NY | Take-home exercise

## P - R

-   [PACE Telematics](https://www.pace.car/jobs) | Karlsruhe, Germany | Culture and mindset check, on-site meet and great, small code challenge to see development style and strategy

-   [Paessler AG](https://www.paessler.com/company/career/jobs) | Nuremberg, Germany | Pairing with different engineers on a real problem

-   [Pagar.me](https://pagar.me/) | São Paulo, BR | Skype interview, on-site pairing task and-or real world problem solving process / presentation

-   [Pager](https://pager.com/) | New York, NY; Remote | Short phone interview, conversational interviews, take-home exercise & discussion

-   [PagerDuty](https://pagerduty.com/careers) | San Francisco, CA / Toronto, Canada / Atlanta, GA | Zoom / on-site pair programming and tasks

-   [Palatinate Tech](https://tech.palatinategroup.com/) | London, UK | Hangout/Skype/phone followed by (normally) on-site pairing task

-   [Parabol](http://parabol.co/) | New York, NY; Los Angeles, CA; Remote | Culture check followed by compensated, [open-source contribution](https://github.com/ParabolInc/action/projects) skills evaluation

-   [Pariveda Solutions](http://parivedasolutions.com/) | Dallas, TX / Houston, TX / Atlana, GA / Washington, DC / New York, NY / Chicago, IL / San Francisco, CA / Seattle, WA / Los Angeles, CA | Personality assessment (Predictive Index) and case study. Programming aptitude test (language independent) for college hires.

-   [PassFort](https://passfort.com/about#jobs) | London, UK | Skype interview, and on-site pairing task

-   [Paws](https://paws.com/careers) | London, UK | Phone screening, take-home project, on-site pairing/discussion on your solution and meet the team.

-   [Paybase](https://paybase.io/) | London, UK | Phone screening, Take home project, On-site interview for technical and culture fit, Open Q\&A session with team

-   [PayByPhone](https://www.paybyphone.com/careers) | Vancouver, Canada | Remote programming interview, on-site "meet the team"

-   [Peaksware Companies (TrainingPeaks, TrainHeroic, MakeMusic)](https://peaksware.com/) | Boulder, CO; Denver, CO | Phone screen, take home project, remote and on-site interviews for technical and cultural fit

-   [PeerStreet](https://info.peerstreet.com/careers) | Los Angeles, CA | Phone, take home project & on-site to meet the team

-   [Pento](https://angel.co/pento/jobs) | Remote | Quick personal interview, take home project

-   [Persgroep, de](https://www.persgroep.nl/werken-bij-it) | Amsterdam, Netherlands | Tech interview (technical background and experiences) and culture fit, both on-site

-   [Pex](https://angel.co/pexeso/jobs) | Los Angeles, CA; Remote | 3 sessions: brief phone conversation (30 min); take home assignment (2 hours); on-site or video discussion without any coding (2 hours)

-   [Phoodster](https://www.phoodster.com/) | Stockholm, Sweden | Take-home exercise + on-site discussion

-   [Pillar Technology](http://pillartechnology.com/careers) | Ann Arbor, MI; Columbus, OH; Des Moines, IA | Phone, take home exercise, in-person pairing session and site visit.

-   [Pilot](https://pilot.co/become-a-partner) | Remote | Two calls. Introduction one (30m) + verification of communication skills and remote work experience (15m)

-   [Pivotal](https://pivotal.io/careers) | San Francisco, CA; Los Angeles, CA; New York, NY; Boston, MA; Denver, CO; Atlanta, GA; Chicago, IL; Seattle, WA; Washington, D.C.; London, UK; Sydney, Australia; Toronto, Canada; Paris, France; Berlin, Germany; Tokyo, Japan | Initial remote technical screen featuring pair programming; on-site pair programming interview, generally a full day pairing on production code using test-driven development.

-   [Platform.sh](https://platform.sh/) | Paris, International | Remote Interview, Wide-Ranging discussions on many diverse subjects. Remote interviews with team members.

-   [Platform45](https://platform45.com/) | Johannesburg, South Africa; Cape Town, South Africa | On-site interview, take-home project and culture fit day

-   [Playlyfe](https://getcatalyst.in/careers) | Bangalore, India | Short personal interview, on-site demonstration of programming in browser devtools followed by discussion about the problem

-   [Pluralsight](https://www.pluralsight.com/careers) | Salt Lake City, UT; San Francisco, CA; Boston, MA; Orlando, FL | Takehome exercise & pair programming session

-   [Pointman](http://pointman.bamboohr.com/jobs/) | Buffalo, NY | Takehome exercise + on-site discussion

-   [Poki](http://jobs.poki.com/) | Amsterdam, The Netherlands | Pair programming on-site w/ two engineers where we focus on teamwork, googling relevant documentation and fixing things together.

-   [Polar](http://polar.me/company/careers) | Toronto, Canada | Phone interview, followed by 1-2 onsite pair-programming interviews based on their platform

-   [Popstand](http://www.popstand.com/) | Los Angeles, CA | Build MVPs for startups

-   [Popular Pays](http://www.popularpays.com/) | Chicago, IL | Phone chat/coffee to determine what will be worked on during a day of pair-programming on a real problem that the candidate thinks best demonstrates their skills.

-   [Pragmateam](https://pragma.team/talent) | Sydney, Australia | Engineering Consultancy And Delivery - Takehome exercise & discussion

-   [PremiumBeat](https://www.premiumbeat.com/careers) | Montreal, Canada | Discussion and general, high level questions

-   [Primary](https://www.primary.com/jobs) | New York, NY / Remote | Phone chat, take home exercise, pair program and discuss onsite.

-   [PromptWorks](https://www.promptworks.com/jobs) | Philadelphia, PA | Take-home project, pair programming, discussion on-site

-   [Pusher](https://pusher.com/jobs) | London, UK | Solve a real-world problem through a design session with our engineers

-   [Pygmalios](http://pygmalios.com/en) | Bratislava, Slovakia | Take-home project related to business and discussion with our engineers.

-   [Quiet Light Communications](https://quietlightcom.com/positions-web.php) | Rockford, IL, USA | Discussion, work samples and/or small freelance project

-   [Quintype](http://www.workatquintype.com/) | Bengaluru, India / San Mateo, USA | Take home project, pair programming, discussion on-site

-   [Quizizz](https://quizizz.com/) | Bengaluru, India | Phone chat, real world assignment, discussion w/ developers, pair programming, discussion on-site

-   [Ragnarson](https://ragnarson.com/) | Lodz, Poland; Remote | Take-home exercise & pair programming session

-   [Railslove](https://www.railslove.com/) | Cologne, Germany | Have a coffee in our office, casual chat with us, pair programming on a real project

-   [Raising IT](https://www.raisingit.com/) | London, UK | Coffee with a team member, on-site pair programming and discussion

-   [Rakuten](https://jobs.rakuten.careers/careersection/rakuten_ext_cs/jobdetail.ftl?job=00000751&tz=GMT%2B09%3A00) | Tokyo, Japan | Discuss about relevant experience

-   [Rapyuta Robotics](http://www.rapyuta-robotics.com/pages/jobs.html) | Bengaluru, India / Tokyo, Japan / Zurich, Switzerland | Take-home assignment related to our ongoing projects, series of technical / experience based interviews, candidate presentation

-   [Rayfeed](https://rayfeed.com/) | Vancouver, Warsaw | Video-call interview followed by a take-home exercise

-   [Razorpay](https://razorpay.com/jobs) | Bangalore, India | Phone screen, On-site pair programming, and ocassionally a take home project.

-   [ReactiveOps](https://reactiveops.com/careers) | Remote | Start with a brief talk with CTO or VP of Engineering, take home coding challenge, then remote interviews with several people on the engineering team

-   [Reaktor](https://reaktor.com/careers) | New York, NY; Amsterdam, Netherlands; Helsinki, Finland; Tokyo, Japan | Discussion, work samples from previous projects (work or hobby), take-home exercise if needed for further info

-   [Real HQ](https://realhq.com/jobs) | Austin, TX / Chicago, IL / Remote | Phone/video interviews, a take-home coding exercise, and a remote pair programming session.

-   [Realync](https://realync.com/careers) | Chicago, IL / Carmel, IN / Remote | Quick phone interview, then a take home project and finally in person interview (open discussions instead of quizzes - anything technical are real-world problems).

-   [Red Badger](https://red-badger.com/about-us/join-us) | London, UK | Phone & Skype interview, take home exercise, On-site interview

-   [RedCarpet](https://www.redcarpetup.com/jobs) | New Delhi, India | Interview, work sample/take-home project and discussion/code reviews

-   [Reflektive](https://www.reflektive.com/careers/) | San Francisco, CA; Bengaluru, India | A short take home project/assignment, followed by a couple of technical and non-technical discussions online and offline.

-   [Relabe](https://relabe.com/) | San Juan, PR | First we screen for cultural fit then check for technical proficiency. 2-3 Interviews max in SJ

-   [Rentify](https://www.rentify.com/jobs) | London, UK | Phone call, take home real-world project, on-site pair programming, product discussion

-   [RentoMojo](https://www.rentomojo.com/about/careers) | Bangalore, India | Short takehome project + phone interview

-   [Resin.io](https://resin.io/) | Remote | Take home real-world project and a couple of technical and non-technical discussions

-   [ReSpark](https://www.respark.co.uk/) | London, UK | Phone conversation followed by on-site interview w/ task relevant to daily role.

-   [RestaurantOps](https://www.restaurantops.co/) | Scottsdale, AZ | Take Home Project & pair programming session

-   [Revlv](https://revlv.net/) | Manila, Philippines | Discussion about developer skills, previous projects and experiences.

-   [Rex Software](https://www.rexsoftware.com/careers) | Brisbane, Australia | Take home project, feedback + interview

-   [Rizk.com](https://rizk.com/) | Ta' Xbiex, Malta | Take-home assignment, discussion w/ developers

-   [Rockode](http://www.rockode.com/) | Bangalore, India | Real world assignment, group hack session, discussions

-   [Rose Digital](http://rosedigital.co/) | New York, NY | Phone conversation followed by pair coding components that mirror day to day work, in person discussion about code, take home project if needed for more info

-   [RubyGarage](https://rubygarage.org/) | Dnipro, UA | Take-home project, code review and discussion on-site

-   [Runtastic](https://www.runtastic.com/) | Linz, Austria; Vienna, Austria | Video call with recruiting staff, take home project, video call for code review, discussion, questions

## S - U

-   [Sahaj Software Solutions](https://www.sahajsoft.com/) | Bangalore, India; Chennai, India; San Jose, CA | Take home code + Pairing + Discussion

-   [Salesforce.org Tech & Products](http://www.salesforce.org/) | Remote | Phone screen, hands-on programming test solving real-world problems, Google Hangouts video sessions with engineers

-   [Salesloft](https://salesloft.com/) | Atlanta, GA | Phone interview, take-home project, cultural-fit interview, technical interview where candidate modifies take-home project

-   [Samsara](https://www.samsara.com/jobs) | San Francisco, CA; Atlanta, GA; London, UK | Phone interview, onsite interview (technical challenges based on real problems we've faced at Samsara)

-   [SC5 Online](https://sc5.io/careers) | Helsinki, Finland; Jyväskylä, Finland | Take-home assignment (intentionally short, takes at most an hour to complete), discussion and review assignments

-   [Segment](https://segment.com/) | San Francisco, CA; Vancouver, Canada | Phone interview, take-home assignment (small fun project), onsite interview (technical + core/culture) -> intended to set you up for success

-   [Sensor Tower](https://sensortower.com/jobs) | San Francisco, CA | Phone call, on-site interview including discussion about projects/skills and a short real-world programming challenge

-   [Sensu](https://sensu.io/) | Remote | Video call, choice of pairing session or take home programming assignment

-   [Séntisis](http://sentisis.com/trabaja-con-nosotros) | Madrid, Spain; Mexico City, Mexico; Bogotá, Colombia; Santiago de Chile, Chile; Remote | Phone call, on-site/remote interview including discussion about projects/skills and a short real-world pair-programming exercise

-   [SerpApi](https://serpapi.com/) | Austin, TX / Remote | Skype core value and culture interview, review of contributions on GitHub or other platforms, and take-home project if online contributions are not enough.

-   [Sertis](https://sertiscorp.com/) | Bangkok, Thailand | Technical & culture fit interview, take-home project, follow-up discussion

-   [Setapp Sp. z o.o.](https://setapp.pl/career) | Poznan, Poland | Online/face-to-face discussion with developers about everyday programming dilemmas & reviewing your own code

-   [Sharoo](https://www.sharoo.com/jobs/) | Zurich, Switzerland; Remote | Soft skills interview, take home project, technical interview based on take home project.

-   [Shogun](https://getshogun.com/) | Remote | Discussion about software development and past experience, code samples, paid trial period.

-   [Showmax](https://blog.showmax.com/engineering-careers) | Beroun, Czechia; Prague, Czechia; Remote | Take home project, then a pair-programming and discussion onsite / Hangouts round.

-   [ShuttleCloud](https://shuttlecloud.com/jobs) | Chicago, IL / Madrid, Spain | Take-home project, then on-site code walk through and a real world problem discussion.

-   [Signal AI](https://www.signal-ai.com/about-us/careers) | London, UK | Phone screen; take home code exercise; on-site code extension with pair programming and discussion

-   [Simple](https://www.simple.com/) | Portland, OR | Discussion about software development and architecture skills and experience.

-   [Simpli.fi](https://www.simpli.fi/about-us/careers) | Fort Worth, TX, USA | Takehome code challenge and review

-   [SimpliField](http://www.welcometothejungle.co/companies/simplifield/jobs) | Lille, France | Interview with the CTO and the developer team

-   [Simply Business](https://www.simplybusiness.co.uk/about-us/careers/tech) | London, UK / Remote | Three stage, one day interview with quick feedback. One of the stages is 1.5h pair-programming session, where interviewee is assigned a task and interviewing developer plays role of Product Owner.

-   [Skyrise Pro](https://www.skyrisepro.com/) | Chicago, IL | Take-home coding project, on-site interview including coding enhancements to the take-home project, offsite group activity

-   [Slack](https://slack.com/jobs) | San Francisco, CA | Call with recruiter, 1 week take-home project, call with hiring manager, on-site interview covering high-level system design, best software development practices and culture-fit

-   [Small Improvements](https://www.small-improvements.com/careers) | Berlin, Germany

-   [Social Tables](http://www.socialtables.com/) | Washington, DC | Chat about skills and past experiences + bring in a code sample from previous work or side project to discuss

-   [SocialCops](http://www.socialcops.com/) | New Delhi, India | A mini project (to be done within 8 days), followed by a discussion with the team you're applying to. Then as the final step, a call with one of the founders.

-   [Softwear](http://nl.softwear.nl/vacatures) | Amsterdam, Netherlands | Writing software for the fashion industry – remotely – in an international team.

-   [Sogilis](http://sogilis.com/) | Grenoble, France | Discussion about interests, practices, and motivation. Presentation/code review/pair programming on a personal or professional project.

-   [Sourcegraph](https://about.sourcegraph.com/jobs) | San Francisco, CA & Remote | Tailored to the candidate, often consists of take-home work, discussion of real-world eng challenges, and product familiarity.

-   [Splice](https://jobs.splice.com/) | New York, NY; Remote | Call with recruiter, 4 hr take-home project, video interview w two engs on take-home exercise, video call with hiring manager, video call w VPE & principal eng to talk about architecture.

-   [Spreedly](https://www.spreedly.com/jobs) | Durham, NC | Take-home project [related to business](https://engineering.spreedly.com/blog/programming-puzzles-are-not-the-answer-how-spreedly-does-work-samples.html)

-   [Springer Nature (Asia)](https://www.natureasia.com/) | Tokyo, Japan | Discussion & Pair programming session

-   [Springer Nature Digital](https://sndigital.springernature.com/) | Berlin, Germany; London, UK | Phone chat; take-home project; then a pairing session based on the project, a technical chat, and a chat with non-technical team members

-   [SpronQ](https://www.spronq.nl/) | Amsterdam, Netherlands | Takehome coding challenge

-   [Square](https://squareup.com/careers) | San Francisco, CA | Pair programming in a work environment

-   [Srijan Technologies](http://srijan.net/) | Delhi, India | General high level questions/discussion followed by Pair programming OR take-home coding challenge

-   [Stardog Union](http://stardog.com/) | Washington, DC; Remote | Technical discussion and general interest conversations

-   [Statflo](http://statflo.com/) | Toronto, Canada | Phone screening, take home project, on-site interview discussing the take home project, high-level architectural brainstorm, and questions about career and team work.

-   [store2be](https://www.store2be.com/de/jobs/tech) | Berlin, Germany | Skype/on-site interview, take-home project

-   [Storm](https://www.stormx.io/about#jobs) | Seattle, WA; Remote | Phone/skype screen --> Take-home coding assignment --> on-site/skype interview loop to discuss assignment; meet-and-greet with other teams --> +1/-1 based on team consensus

-   [STYLABS](http://www.stylabs.in/) | Mumbai, India | Phone Screen, Take-home project and discussion on-site

-   [Subvertical (VerticalChange)](https://verticalchange.com/job_posts) | Remote | Phone screening, live pair programming & personal project code review

-   [Sulvo](https://sulvo.com/careers) | New York, NY / Remote | Interview over video call for cultural fit first, if you pass we proceed with technical interview that doesn't include coding games or challenges

-   [Superplayer](https://superplayer.fm/) | Porto Alegre, Brazil | Skype/On-site interview, take-home project and interview with CTO and CEO

-   [SurveySparrow](https://surveysparrow.com/careers) | Kochi, India | Skype interview, take home project and code review, interview with CTO and CEO

-   [SVTi (Sveriges Television)](http://svti.svt.se/) | Stockholm, Sweden | On-site interview, take-home project, follow up interview where you walk through how you chose to solve the task.

-   [SweetIQ](https://sweetiq.com/about/careers) | Montreal, Canada | Discussion and general, high level questions

-   [Symphony Commerce](https://www.symphonycommerce.com/careers) | San Francisco, CA / Remote | Take-home project (phone), design discussion, review and critique *our* code, debugging questions

-   [Symplicity](https://www.symplicity.com/about/join-us) | Arlington, VA | Take-home project and code review in-person

-   [SysGarage](http://sysgarage.com/) | Buenos Aires, Argentina | Take-home project and real world pair programming

-   [TableCheck](https://corp.tablecheck.com/en/jobs) | Tokyo, Japan | Show us your code! Brief Skype interview and take-home project or pairing for those without code.

-   [Tailor Brands](https://tailorbrands.com/jobs) | Tel Aviv-Yafo, Israel | Discuss knowledge and interests, explore previous work experience, during the technical interview we discuss real-life problems.

-   [tails.com](https://tails.com/careers) | Richmond (London), UK | Live pair programming or take home project with review

-   [Tanooki Labs](http://tanookilabs.com/) | New York, NY | Paid half-day take home project with followup review and discussion

-   [Tattoodo](https://www.tattoodo.com/) | Copenhagen, Denmark | Takehome exercise

-   [Telus Digital](https://labs.telus.com/) | Toronto, Canada; Vancouver, Canada | Discuss knowledge and interest, explore previous work, pair with developers when possible, alternatively take home project.

-   [Ten Thousand Coffees](https://tenthousandcoffees.com/) | Toronto, Canada | Take home project, then explain how you solved the project

-   [Tes](https://engineering.tes.com/recruitment/) | Remote; London, UK | Remote pair programming session on React/Node kata with small takehome exercise as prep. Remote interview with senior engineers about previous experience, technical knowledge and interests.

-   [Tesco PLC](https://www.tesco.com/) | London, United Kingdom | Pair programming and casual hypothetical system design discussion

-   [Test Double](https://testdouble.com/join/developer) | Remote | Initial conversation, Consulting interview, Technical interview, Pair programming, Takehome exercise.

-   [Textio](https://textio.com/careers/?utm_source=github&utm_medium=forum&utm_campaign=textio-careers-engineering&utm_content=poteto-hiring-without-whiteboards) | Seattle, WA | Initial screen to discuss experience and interest in a role at Textio; then a take-home programming task is discussed during a 1-hour tech screen (on-site or remote); finally a larger take-home project, simulating real work, is discussed during an on-site presentation plus 1-1s; [How we hire](https://textio.ai/how-we-hire-a74cdbadd1e8)

-   [The Book of Everyone](https://thebookofeveryone.workable.com/) | Barcelona, Spain | Quick interview, meet the team, pairing with developers on your own project

-   [theScore](http://mobile.thescore.com/careers) | Toronto, Canada | Coding challenge & systems design challenge

-   [Thinkmill](https://www.thinkmill.com.au/) | Sydney, Australia | Initial meet and greet interview with Thinkmillers from the relevant team, take home assignment followed by tech review on a followup interview.

-   [Thinslices](http://www.thinslices.com/) | Iasi, Romania | Takehome exercise & in person pair programming on a simple Kata.

-   [thoughtbot](https://thoughtbot.com/jobs) | San Francisco, CA; London, UK | [Our interview process](https://thoughtbot.com/playbook/our-company/hiring#interviewing)

-   [ThoughtWorks](https://www.thoughtworks.com/careers) | San Francisco, CA | Interviews with ThoughtWorkers of diverse backgrounds and roles; take home assignment followed by in person pairing session.

-   [Thread](https://www.thread.com/jobs) | London, UK | Take home test, real world architecture design, real world pair programming.

-   [ThreatSpike Labs](https://www.threatspike.com/) | London, UK | Take home computing and security related challenges to be completed over a week.

-   [Tilde](http://www.tilde.io/) | Portland, OR | Pair programming sessions with each member of the team, working on problems similar to daily work.

-   [Timbuktu](https://www.timbuktutravel.com/) | Cape Town, South Africa | On site interview and pair programming exercise

-   [Titanium](https://titanium.codes/) | Moldova, Chisinau | High level review of public activity on GitHub/BitBucket/Gitlab (if applicable) and screening via phone, On-site technical & Team fit interview, Formal "Meet the Team" meeting

-   [Toggl](https://toggl.com/jobs) | Remote / Tallinn, Estonia | Online test on basic programming skills, followed by interview (typically includes get-to-know questions and technical skill testing). Depending on the team, there may be a take-home or live coding assignment. **Paid test week** to work with the team on actual bugs/features.

-   [Torii](https://jobs.jointorii.co/) | Raanana, Israel | Take-home fun full-stack-app exercise followed by an on-site review

-   [Toucan Toco](http://toucantoco.com/fr/team#jobs) | Paris, France | Pair-programming and TDD

-   [Touché](https://gotouche.com/) | Singapore, Singapore; Barcelona, Spain | Skype / Phone / on-site interview, take-home project, technical interview to discuss the project, team interview.

-   [TrademarkVision](https://trademark.vision/) | Brisbane, Australia | On site interview and quick take-home excercise

-   [TrainHeroic](http://trainheroic.com/careers/) | Boulder, CO; Denver, CO | Phone screen, take home project, remote and on-site interviews for technical and cultural fit

-   [TrainingPeaks](http://www.trainingpeaks.com/careers.html) | Boulder, CO; Denver, CO | Phone screen, take home project, remote and on-site interviews for technical and cultural fit

-   [TripStack](http://www.tripstack.com/company/careers/) | Toronto, Canada | Take-home assignment, followed up by a face to face code walk through

-   [Trivago](https://www.trivago.com/) | Düsseldorf, Germany | Case Study, Skype Interview, On site Interview with some code review exercises

-   [Trōv](https://boards.greenhouse.io/trov) | Remote | Take-home project with followup interview from actual prospective teammates

-   [Truefit](https://truefit.io/about/) | Pittsburgh, PA | Phone screen, Take-home project, In-person interview with the team that you would join

-   [Truora](https://truora.com/) | Bogotá, Colombia; Cali, Colombia; Remote | Take-home project, followed by phone interview with tech leads to discuss the project.

-   [Truss](https://truss.works/jobs) | San Francisco, CA; Remote | Phone screen/ Take-home project that resembles a problem Truss has seen many times before / Followup interview about the project / Closing Interview, all interviews done remotely

-   [Twistlock](https://www.twistlock.com/) | Tel Aviv, Israel | Takehome

-   [uberall](https://uberall.com/en/careers) | Berlin, Germany | 30-min coding on-site, then a trial day

-   [uBiome](https://ubiome.com/careers) | San Francisco, CA / Santiago, Chile | High level screening over the phone or on-site, take home project, code review and discussion

-   [Ubots](http://ubots.com.br/) | Porto Alegre, Brazil | Skype/On-site interview, take-home project, technical interview

-   [Unbounce](https://unbounce.com/) | Vancouver, BC | Phone screen, take-home project, project discussion, technical interview

-   [Unboxed](https://unboxed.co/) | London, UK | Take home feature requests, pairing with developers to extend solution, team-fit interviews, chat with a director

-   [Unearth](http://www.unearthlabs.com/careers) | Seattle, WA | Take home project, team-fit interviews, technical discussion

-   [Unito](https://unito.io/careers/) | Montreal, Canada | Team-fit interviews, technical discussion, take home project

-   [Untappd](https://www.untappd.com/) | Wilmington, NC; New York, NY; Los Angeles, CA | Review portfolio - What projects have you worked on? + personality assessment, + interview

-   [Updater](http://www.updater.com/jobs/openings) | New York, NY | Begin-at-home assignment highly relevant to role, presented and discussed during on-site.

-   [Uprise](http://uprise.se/) | Uppsala, Sweden | Take-home assignment, code review and discussion on-site

-   [Urban Massage](https://www.urbanmassage.com/jobs) | London, UK | Project done at home, in-person walk through. Meeting the team is an integral part.

-   [UserTesting](https://www.usertesting.com/about-us/jobs) | Atlanta, GA; San Francisco, CA; Mountain View, CA | Initial interview, pair programming, and offer

-   [uSwitch](https://www.uswitch.com/vacancies) | London, UK | Take-home project related to our business area, followed by pairing with developers to extend it

## V - X

-   [Valassis Digital](http://www.valassis.com/digital-advertising) | Seattle, WA; San Francisco, CA; Lansing, MI; Hamburg, Germany | Phone screen, on-site interview with group, paired whiteboard problem solving and discussion, take-home project and follow-up review

-   [Valuemotive](https://valuemotive.com/en/career) | Helsinki, Finland | Code examples from previous projects (work or hobby) or take-home exercise

-   [Varsity Tutors](https://www.varsitytutors.com/) | Remote | Take home assignment, presentation of assignment, live code review with team. Advanced / high-level chat with team based on skillset and role.

-   [Vayu Technology](http://vayu.com.au/) | Sydney, Australia; Kathmandu, Nepal | Short interview, general programming questions and short take home challenge.

-   [Venminder, Inc.](https://www.venminder.com/) | Elizabethtown, KY; Louisville, KY | Initial phone screen to explain position. If candidate interested they get a take home assignment followed by a non-scripted in-person interview with team members to judge personality fit.

-   [Verve](https://verve.co/careers) | London, UK | An intentionally short, take home exercise that mirrors real project work and incorporates code review elements

-   [Vingle](https://careers.vingle.net/) | Seoul, Korea | Written interview, takehome project, in-person, conversational code review and interviews with engineers and engineering managers

-   [virtual7](http://virtual7.de/de/karriere) | Kalrsruhe, Germany | Phone interview and on-site interview based on personal experience.

-   [Visma e-conomic](https://www.e-conomic.dk/om/job) | Copenhagen, Denmark | Take home assignment, assignment presentation and discussion

-   [Voltra Co.](https://voltra.co/) | Amsterdam, Netherlands / New York, NY / Remote | Show us your github account, tell us what you know. Let's pair on an OSS PR!

-   [VSX](https://https//vsx.net/jobs) | Dresden, Germany | On-site interview, home coding challenge, presentation/discussion of proposed solutions

-   [VTEX](http://lab.vtex.com/careers) | Rio de Janeiro, Brazil | Take-home project, Skype interview and then in-person talk.

-   [VTS](https://buildingvts.com/) | New York City, New York | Technical Phone Screen, Pair programming on-site & in-person talks with multiple engineers

-   [Waymark](https://waymark.com/jobs) | Detroit, MI | Technical phone screen, take-home project, going over the project in person, follow up day in the office

-   [Wealthsimple](https://www.wealthsimple.com/work-with-us) | Toronto, Canada | Pair programming on a problem similar to daily work, discussion of system design

-   [WeAreHive](http://www.wearehive.co.uk/) | London, UK | Just walk us through your best code or we give you a small real-world exercise to do at home.

-   [Webantic](https://webantic.co.uk/careers) | Manchester, UK | Basic TNA self-assessment and real-world problem-solving

-   [Webflow](https://webflow.com/) | San Francisco, CA & Remote | Short take-home challenge, followed by a paid 3-5 day freelance contract project

-   [Weebly](http://careers.weebly.com/) | San Francisco, CA; Scottsdale, AZ; New York, NY | Phone screens (30 min to 1 hour) by a recruiter, an engineering manager (focused on your past experiences), an engineer (focused on system / db / api design). Followed by a paid 3 day onsite where you work on a project and then present it to a team of engineers.

-   [Weedmaps](https://weedmaps.com/careers) | Irvine, CA; Denver, CO; Tucson, AZ; Madrid, Spain; Remote | Phone screen, Group interview, and possible code review

-   [wemake.services](https://wemake.services/) | Remote | Short unpaid take-home challenge, code review, portfolio discussion

-   [Weploy](https://www.weployapp.com/join-our-team/) | Melbourne, Australia; Sydney, Australia | Phase 1: Face to face interview to get to know the candidate. Phase 2: Problem solving session that involves designing a solution to a real-world problem followed by 1/2 day of pairing with a senior dev on implementing the proposed solution.

-   [WeTransfer](https://wetransfer.homerun.co/) | Amsterdam, Netherlands | Culture fit and fundamentals chat, skills interview - no whiteboarding! - and take-home project, communication and collaboration interview, meet with the VP of Engineering

-   [Wheely](https://wheely.com/en/careers) | Moscow, Russia | Get to know each other in under 30 minutes on-site or via Skype, take-home challenge, on-site review and interview with the team.

-   [Wildbit](https://wildbit.com/) | Philadelphia, PA & Remote | Take-home project followed by interviews.

-   [Wirecard Brasil](https://wirecardbrasil.workable.com/) | São Paulo, Brazil | Phone or on-site Cultural Fit interview, take-home coding challenge, code review and discussing in-person.

-   [WorldGaming](https://worldgaming.com/) | Toronto, Canada | Technical Interview, Solution Design, Take Home Assignment, then Culture fit interview with the team

-   [woumedia](https://woumedia.com/) | Remote | Getting to know each other and aligning expectations. Talking about past experiences, projects you are proud of and latest challenges you faced. It's followed by a use case study from one of our current projects.

-   [WyeWorks](https://wyeworks.com/) | Montevideo, Uruguay | Take-home project and discussion on-site

-   [X-Team](http://x-team.com/) | Remote | A short, fun Node.js challenge, followed by a series of culture-based interview questions, followed by a creative mock project with tons of freedom on how to approach, and follow-up questions about the approach they chose to discuss the tradeoffs. Usually a 10-30 day paid training is rewarded to top candidates to prep them for remote communication skills needed to join a team.

-   [XING](https://www.xing.com/) | Hamburg, Germany | Take-home coding challenge, on-site review and short interviews with future team.

## Y -

-   [1000mercis group](http://www.1000mercis.com/#!/careers/?lang=en) | Paris, France | Series of interviews, that go over technical background, past experiences and cultural knowledge

-   [18F](https://18f.gsa.gov/join/) | Remote; Washington, DC; New York, NY; Chicago, IL; San Francisco, CA | take-home coding exercise (2-4 hours), technical and values-match interviews over video chat

-   [3D Hubs](https://3dhubs.com/jobs) | Amsterdam, The Netherlands | Take-home code challenge from our product's domain followed by discussion remote/on-site, sometimes do an additional on-site pair programming session.

-   [500friends](http://500friends.com/who-we-are/careers) | San Francisco, CA; Remote | Take home challenge followed by onsite expansion of the submission and high level discussions (design exercise or overview of past projects)

-   [500Tech](https://500tech.com/) | Tel Aviv, Israel | Pair programming on a laptop in working env

-   [8th Light](https://8thlight.com/) | Chicago, IL; London, UK; Los Angeles, CA; New York, NY | Take home code challenge, discussion, pair programming session

-   [Yhat](https://www.yhat.com/jobs) | Brooklyn, NY | Demo something cool you built and walk us thru the code + design decisions

-   [YLD](https://yld.breezy.hr/) | London, UK | Take home-code challenge, pair-programming session and discussion about past experience

-   [Yodas](https://yodas.com/) | Binyamina, Israel | Coding tasks over github repository

-   [Yoyo Wallet](http://yoyowallet.com/) | London, UK | Take home code challenge, discussion of the code challenge, and general, high level questions

-   [YunoJuno](http://www.yunojuno.com/) | London, UK | Code challenge based on a realistic feature request on a real open-source package created and used at YunoJuno; phone/video interview with members of the Product team to explore technical background, experiences, interests, cultural fit; on-site interview, usually with Product Manager and CTO

-   [ZAP Group](https://jobs.kenoby.com/grupozap/) | São Paulo, Brazil | Takehome exercise, series of real-world interviews with engineers, HR, engineering managers and product managers on site.

-   [Zencargo](https://www.zencargo.com/careers) | London, UK | Initial interview with CTO, covering professional experience interests and expectations, followed by one technical interview focused on fundamentals and familiarity with best practices. A further short chat with co-founders to get to know each other - - either onsite or remote.

-   [Zenefits (UI Team)](https://www.zenefits.com/careers) | San Francisco, CA | One technical phone screen focused on JS fundamentals and/or one timeboxed take-home challenge. The onsite is a series of interviews designed to test your understanding of JS, HTML/CSS, design, etc.

-   [Zerodha](https://zerodha.com/careers) | Bengaluru, India | Technical call at the beginning and one take home programming task.

-   [Zype](https://boards.greenhouse.io/zype) | New York, NY & Remote | Skype/Video call with VP of Product and a take-home challenge.
