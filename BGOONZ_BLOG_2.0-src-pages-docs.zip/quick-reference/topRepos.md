---
title: Top Repos
weight: 0
seo:
    title: Top Repos
    description: This is the Top Repos page
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Top Repos
          keyName: property
        - name: 'og:description'
          value: This is the Top Repos page
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Top Repos
        - name: 'twitter:description'
          value: This is the Top Repos page
template: docs
---

# My Top Repos / Websites:

-   [Python Practice](https://github.com/bgoonz/PYTHON_PRAC)
-   [Lambda Bootcamp Website](https://lambda-resources.netlify.app/)
-   [React Notes](https://github.com/bgoonz/React_Notes_V3)
-   [Project Showcase](https://github.com/bgoonz/Project-Showcase)
-   [Data Structures & Algorithms](https://github.com/bgoonz/DS-ALGO-OFFICIAL)
-   [Lambda Site Static Content Server](https://github.com/bgoonz/Lambda-Resource-Static-Assets)
-   [Mini-Project Showcase](https://github.com/bgoonz/mini-project-showcase)
-   [Useful Snippets](https://github.com/bgoonz/Useful-Snippets-js)
-   [Markdown Templates](https://github.com/bgoonz/Markdown-Templates)
-   [Zumzi Video Conferencing App (mesibo api backend)](https://github.com/bgoonz/zumzi-chat-messenger)

https://pages.databricks.com/rs/094-YMS-629/images/dynamic-time-warping-background.html
