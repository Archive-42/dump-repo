---
title: Markdown Dropdown
weight: 0
excerpt: Markdown Dropdown
seo:
    title: ''
    description: ''
    robots: []
    extra: []
template: docs
---

# Markdown Dropdown:

<details>
<summary>How do I dropdown?</summary>
<br>
This is how you dropdown.
<br>
<br>
<pre>
&lt;details&gt;
&lt;summary&gt;How do I dropdown?&lt;&#47;summary&gt;
&lt;br&gt;
This is how you dropdown.
&lt;&#47;details&gt;
</pre>
</details>

---

<details open>
<summary>Want to ruin the surprise?</summary>
<br>
Well, you asked for it!
<br>
<br>
<pre>
&lt;details open&gt;
&lt;summary&gt;Want to ruin the surprise?&lt;&#47;summary&gt;
&lt;br&gt;
Well, you asked for it!
&lt;&#47;details&gt;
</pre>
</details>
