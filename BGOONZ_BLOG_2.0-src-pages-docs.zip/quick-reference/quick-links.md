---
title: Quick Links
weight: 0
excerpt: lorem-ipsum
seo:
    title: ''
    description: ''
    robots: []
    extra: []
template: docs
---

# Gitbook Websites:

-   [Python](https://bryan-guner.gitbook.io/datastructures-in-pytho/)

-   [General](https://bryan-guner.gitbook.io/web-dev-hub-docs/)

-   [Blockchain & NFTs](https://bryan-guner.gitbook.io/solidarity-blockchain-nfts/)

-   [React](https://bryan-guner.gitbook.io/mynotes/)

# Sites I Wish To Revisit:

-   [Hasura](https://hasura.io/learn/)
