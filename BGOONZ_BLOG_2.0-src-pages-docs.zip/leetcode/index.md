---
title: Leetcode
weight: 0
excerpt: feel free to try the examples
seo:
    title: Leetcode Examples
    description: Leetcode practice
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<br>
<br>
<h1>Leetcode </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://web-dev-collaborative.github.io/Leetcode-JS-PY-MD/" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://web-dev-collaborative.github.io/Leetcode-JS-PY-MD/old_index.html" height="1000px" style="width: 1300px; scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
