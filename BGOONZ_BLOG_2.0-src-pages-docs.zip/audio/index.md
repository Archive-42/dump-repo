---
title: Audio
weight: 0
excerpt: Audio Projects
seo:
    title: Audio Projects
    description: A collection of web audio projects
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

<br>
<br>
<br>

<iframe width="100%" height="500" frameborder="0"
src="https://bgoonz.github.io/extracting-features-from-audio/"></iframe>
<hr>
<br>
<iframe width="100%" height="500" frameborder="0"
src="https://observablehq.com/embed/@bgoonz/mode-lighting/2?cell=*"></iframe>
<br>
<br>
<br>

<hr>
<br>
    <iframe
      width="100%"
      height="1000"
      frameborder="0"
      src="https://observablehq.com/embed/@bgoonz/determining-the-key-of-bwv1001-1st-movement-adagio?cell=*"
    ></iframe>
<br>
<br>
<br>
<hr>
<br>
    <iframe
      width="100%"
      height="784"
      frameborder="0"
      src="https://observablehq.com/embed/@bgoonz/can-sound-add-value-to-data-visualizations?cells=viewof+chart"
    ></iframe>
<br>
<br>
<br>

<hr>
<br>
