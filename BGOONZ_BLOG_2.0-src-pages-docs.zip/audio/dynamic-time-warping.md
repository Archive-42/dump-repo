---
title: dynamic-time-warping
weight: 0
excerpt: dynamic-time-warping
seo:
    title: 'dynamic-time-warping'
    description: 'dynamic-time-warping'
    robots: []
    extra: []
template: docs
---

# Dynamic Time Warping Triggered Guitar Effects Project:

# DTW Algorithm:

<iframe src="https://onedrive.live.com/embed?cid=D21009FDD967A241&amp;resid=D21009FDD967A241%21634692&amp;authkey=AHfsGpj1Un3UNuE&amp;em=2&amp;wdAr=1.7777777777777777" width="962px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>

---

# Project:

<iframe src="https://onedrive.live.com/embed?resid=D21009FDD967A241%21608188&amp;authkey=%21AL1vMFzOuqvFbUY&amp;em=2&amp;wdAr=1.7777777777777777" width="962px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
