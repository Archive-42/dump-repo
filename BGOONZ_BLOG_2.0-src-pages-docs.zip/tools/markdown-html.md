---
title: md and html
weight: 0
excerpt: Tools For Markdown & Html
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

## Tools For Markdown & Html

<br>
<br>
<br>
<br>

<h1>   Paste To Markdown </h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://euangoddard.github.io/clipboard2markdown/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
        
        
   
<br>
<br>
<h1>   Paste Excel Tabel To Markdown </h1>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://codepen.io/bgoonz/embed/JjNaPpL?default-tab=result&theme-id=light" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<h1>Paste excel to HTML</h1>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://pedantic-wing-adbf82.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
