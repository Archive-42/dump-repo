---
title: General Utilities
weight: 0
excerpt: General Utilities
seo:
    title: ''
    description: ''
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---

## General Utilities

<br>
<br>
<br>
<h1> Semvar Checker </h1>
<br>

<iframe src="https://semvar-checker-tool-beta.vercel.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>


<hr>
<br>
<br>
<hr>
<br>

<hr>
<br>
<br>
<br>
<h1> Photo Editor   </h1>
<br>

<iframe src="https://onlinephotoeditor.goonlinetools.com/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<hr>
<br>
<br>
<br>

<h1>  Github HTML Render from link </h1>
<br>

<iframe src="https://githtmlpreview.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>

<h1> Form Builder GUI </h1>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="https://fourm-builder-gui.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<hr>
<br>

<h1> Border Builder </h1>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="https://codepen.io/bgoonz/embed/zYwLVmb?default-tab=html%2Cresult" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<br>

## Archives

<br>
<br>
<br>
<h1> Original Blog Site </h1>
<br>


<iframe src="https://web-dev-resource-hub.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<hr>
<br>
<br>
<br>

<hr>
<br>
<br>
<br>

<h1> Ternary Converter   </h1>
<br>
<iframe src="https://ternary42.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<br>
<hr>
<br>
<br>

<iframe height="1000px" width="1400px" scrolling="yes" title="Dashed Border Generator" src="https://codepen.io/bgoonz/embed/preview/zYwLVmb?default-tab=result&editable=true&theme-id=dark" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/bgoonz/pen/zYwLVmb">
  Dashed Border Generator</a> by Bryan C Guner (<a href="https://codepen.io/bgoonz">@bgoonz</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
