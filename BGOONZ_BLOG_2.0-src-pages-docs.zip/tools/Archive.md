---
title: Archive
weight: 0
excerpt: more tools that I have created or collaborated on.
seo:
    title: ''
    description: 'embeded developer tools and utilities'
    robots: []
    extra: []
    type: stackbit_page_meta
template: docs
---



<br>
<br>
<br>
<h1> Archive</h1>
<br>

<iframe src="https://resourcerepo2.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<hr>
<br>
<br>
<hr>
<br>
 <iframe  style="z-index:-1!important; overflow:scroll;resize:both;"  width="400" height="575"
            src="https://bgoonz.blogspot.com/"  
           frameborder="0" allow="accelerometer; autoplay; clipboard-write;
            encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1>     Resource Archive           </h1>
<br>
<br>
<br>
<br>

<iframe src="https://resourcerepo2.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1> Google Drive</h1>
<iframe src="https://drive.google.com/embeddedfolderview?id=1DHyQsPLziqSUODclplhnNX1eknzbZrL8#list" style="width:100%; height:600px; border:0;"></iframe>


<br>
<br>
<br>
<br>
<br>

<h1>  Cloud Storage </h1>
<br>

<h2> Up to 1TB of cloud Storage for file sharing!</h2>
<iframe src="https://onedrive.live.com/embed?cid=D21009FDD967A241&resid=D21009FDD967A241%21538729&authkey=AHSDSyoYqzg2K2E" height="1000px" width="1300px">
</iframe>

<br>
<br>
<hr>
<hr>
<br>
<br>
<br>

<br>
<br>
<h1>    Internet Archive        </h1>
<br>
<br>
<br>
<br>
<iframe src="https://archive.org/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1>   Lambda Student Site </h1>
<br>
<br>
<br>
<br>

<iframe class="inner" src="https://lambda-resources.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1>   Bass Station CSS Showcase</h1>
<br>
<br>
<br>
<br>

<iframe class="inner" src="https://bgoonz.github.io/bass-station/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1>  Interview     </h1>
<br>
<br>
<br>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="https://web-dev-interview-prep-quiz-website.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>



<h1>   Speach Recognition api </h1>
<br>
<br>
<br>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://random-static-html-deploys.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<br>




<h1>  The Algos Bgoonz Branch </h1>
<br>
<br>
<br>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://thealgorithms.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<br>




<br>
<br>
<br>
<br>

<h1>Markdown Templates</h1>
<br>
<br>
<br>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://markdown-templates-42.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>

<h1>CURL</h1>
<br>
<br>
<br>
<br>
<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" class="block-content" src="https://bgoonz.github.io/everything-curl/index.html" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<h1> Text Tools     </h1>
<br>
<br>
<br>
<br>

<iframe src="https://devtools42.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1> Ternary Converter   </h1>
<br>
<br>
<br>
<br>
<iframe src="https://ternary42.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1>  Github HTML Render from link </h1>
<br>
<br>
<br>
<br>

<iframe src="https://githtmlpreview.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1> Form Builder GUI </h1>
<br>
<br>
<br>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="https://fourm-builder-gui.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>

<h1> Border Builder </h1>
<br>
<br>
<br>
<br>

<iframe  style="z-index:-1!important; overflow:scroll;resize:both;" src="https://codepen.io/bgoonz/embed/zYwLVmb?default-tab=html%2Cresult" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>

<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>

## Archives

<br>
<br>
<br>
<br>
<hr>
<br>
<br>
<br>

<br>
<h1> Original Blog Site </h1>
<br>
<br>
<br>
<br>

<iframe src="https://web-dev-resource-hub.netlify.app/" height="1000px" width="1400px" scrolling="yes" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true"  frameborder="0" ></iframe>
<br>
<br>
<br>
<br>
