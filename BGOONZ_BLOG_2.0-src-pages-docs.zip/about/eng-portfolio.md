---
title: Engineering Portfolio
weight: 0
seo:
    title: Engineering Portfolio
    description: >-
        This is an Engineering Portfolio page that contains a powerpoint portfolio of my work as
        an electrical engineer!
    extra:
        - name: 'og:type'
          value: website
          keyName: property
        - name: 'og:title'
          value: Engineering Portfolio
          keyName: property
        - name: 'og:description'
          value: This is the Engineering Portfolio page
          keyName: property
        - name: 'twitter:card'
          value: summary
        - name: 'twitter:title'
          value: Engineering Portfolio
        - name: 'twitter:description'
          value: This is the Engineering Portfolio page
template: docs
---

# Portfolio

<iframe src="https://onedrive.live.com/embed?cid=D21009FDD967A241&amp;resid=D21009FDD967A241%21671966&amp;authkey=APaBpP1yOouJY88&amp;em=2&amp;wdAr=1.7777777777777777" width="1186px" height="691px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>

<iframe src="https://codesandbox.io/embed/bold-surf-xfsiq?fontsize=14&hidenavigation=1&theme=dark&view=preview"
style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;"
title="bold-surf-xfsiq"
allow="accelerometer; ambient-light-sensor; camera; encrypted-media; geolocation; gyroscope; hid; microphone; midi; payment; usb; vr; xr-spatial-tracking"
sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts"
></iframe>
